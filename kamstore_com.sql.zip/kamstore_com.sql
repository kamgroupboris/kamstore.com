-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Июн 17 2016 г., 16:40
-- Версия сервера: 5.7.9
-- Версия PHP: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `kamstore.com`
--

-- --------------------------------------------------------

--
-- Структура таблицы `s_auth_assignment`
--

DROP TABLE IF EXISTS `s_auth_assignment`;
CREATE TABLE IF NOT EXISTS `s_auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `s_auth_assignment`
--

INSERT INTO `s_auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('admin', '9', 1464972454),
('author', '18', 1464972454);

-- --------------------------------------------------------

--
-- Структура таблицы `s_auth_item`
--

DROP TABLE IF EXISTS `s_auth_item`;
CREATE TABLE IF NOT EXISTS `s_auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `s_auth_item`
--

INSERT INTO `s_auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`) VALUES
('admin', 1, NULL, NULL, NULL, 1464972454, 1464972454),
('author', 1, NULL, NULL, NULL, 1464972454, 1464972454),
('createPost', 2, 'Create a post', NULL, NULL, 1464972454, 1464972454),
('updatePost', 2, 'Update post', NULL, NULL, 1464972454, 1464972454);

-- --------------------------------------------------------

--
-- Структура таблицы `s_auth_item_child`
--

DROP TABLE IF EXISTS `s_auth_item_child`;
CREATE TABLE IF NOT EXISTS `s_auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `s_auth_item_child`
--

INSERT INTO `s_auth_item_child` (`parent`, `child`) VALUES
('admin', 'author'),
('author', 'createPost'),
('admin', 'updatePost');

-- --------------------------------------------------------

--
-- Структура таблицы `s_auth_rule`
--

DROP TABLE IF EXISTS `s_auth_rule`;
CREATE TABLE IF NOT EXISTS `s_auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `s_blog`
--

DROP TABLE IF EXISTS `s_blog`;
CREATE TABLE IF NOT EXISTS `s_blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `url` varchar(255) NOT NULL,
  `meta_title` varchar(500) NOT NULL,
  `meta_keywords` varchar(500) NOT NULL,
  `meta_description` varchar(500) NOT NULL,
  `annotation` text NOT NULL,
  `text` longtext NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  `date` timestamp NOT NULL DEFAULT '2014-10-31 05:03:55',
  PRIMARY KEY (`id`),
  KEY `enabled` (`visible`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_blog`
--

INSERT INTO `s_blog` (`id`, `name`, `url`, `meta_title`, `meta_keywords`, `meta_description`, `annotation`, `text`, `visible`, `date`) VALUES
(1, 'Что нового в этом магазине', 'chto-novogo-v-etoj-versii-simply', 'Что нового в этом магазине', 'Что нового в этом магазине', '', 'Новый магазин', '<p>&nbsp;</p><div><p>Сортировка товаров и других списков перетаскиванием, в том числе перетаскивание в другую категорию или бренд<br />Указание "бесконечного" количество товара на складе<br />Акционная цена (указание старой цены товара)<br />Авторесайз изображений imagick<br />Поддержка jpg, png и gif, в том сисле с анимацией и прозрачностью<br />Водяной знак для изображений<br />Модерация комментариев к товарам</p><h2>Снаружи</h2><p>Аяксовая корзина<br />Фильтр товаров по характеристикам с учетом существования товаров<br />Сортировка товаров по цене и названию</p><h2>Заказы</h2><p>Полное редактирование заказов<br />Примечания администратора к заказам<br />Возможность не включать в заказ стоимость доставки<br />Статистика заказов по дням</p><h2>Блог</h2><p>Блог вместо статей и новостей<br />Комментарии к записям в блоге<br />Модерация комментариев к записям в блоге</p><h2>Импорт</h2><p>Импорт характеристик товаров<br />Импорт изображений с другого сервера<br />Снято ограничение на объем импортируемого файла (теперь ограничение только в настройках сервера)</p><h2>Экспорт</h2><p>Экспорт характеристик товаров<br />Снято ограничение на объем экспорта</p><h2>Редактирование шаблонов</h2><p>Сохранение изменений без перезагрузки страницы<br />Размер изображений задаётся на месте их вывода в шаблоне</p><h2>Валюты</h2><p>Указание формата валют и возможность округления до рублей</p><h2>1C</h2><p>Синхронизация с 1С (товары и заказы)</p></div><p>&nbsp;</p>', 1, '2011-10-22 21:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `s_brands`
--

DROP TABLE IF EXISTS `s_brands`;
CREATE TABLE IF NOT EXISTS `s_brands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `meta_title` varchar(500) NOT NULL,
  `meta_keywords` varchar(500) NOT NULL,
  `meta_description` varchar(500) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_brands`
--

INSERT INTO `s_brands` (`id`, `name`, `url`, `meta_title`, `meta_keywords`, `meta_description`, `description`, `image`) VALUES
(1, 'Apple', 'apple', 'Apple', 'Apple', 'Apple', '', ''),
(2, 'Samsung', 'samsung', 'Samsung', 'Samsung', 'Samsung', '', ''),
(3, 'Nokia', 'nokia', 'Nokia', 'Nokia', 'Nokia', '', ''),
(4, 'HTC', 'htc', 'HTC', 'HTC', 'HTC', '', ''),
(5, 'Sony Ericsson', 'sony-ericsson', 'Sony Ericsson', 'Sony Ericsson', 'Sony Ericsson', '', ''),
(6, 'BlackBerry', 'blackberry', 'BlackBerry', 'BlackBerry', 'BlackBerry', '', ''),
(7, 'Dyson', 'dyson', 'Dyson', 'Dyson', 'Dyson', '', ''),
(8, 'Electrolux', 'electrolux', 'Electrolux', 'Electrolux', 'Electrolux', '', ''),
(9, 'Zelmer', 'zelmer', 'Zelmer', 'Zelmer', 'Zelmer', '', ''),
(10, 'Nikon', 'nikon', 'Nikon', 'Nikon', 'Nikon', '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `s_categories`
--

DROP TABLE IF EXISTS `s_categories`;
CREATE TABLE IF NOT EXISTS `s_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `meta_title` varchar(255) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `url` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL DEFAULT '',
  `position` int(11) NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `external_id` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `url` (`url`),
  KEY `parent_id` (`parent_id`),
  KEY `position` (`position`),
  KEY `visible` (`visible`),
  KEY `external_id` (`external_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_categories`
--

INSERT INTO `s_categories` (`id`, `parent_id`, `name`, `meta_title`, `meta_keywords`, `meta_description`, `description`, `url`, `image`, `position`, `visible`, `external_id`) VALUES
(1, 0, 'Мобильные телефоны', 'Мобильные телефоны', 'Мобильные телефоны', '', '', 'mobilnye-telefony', '', 1, 1, ''),
(2, 0, 'Бытовая техника', 'Бытовая техника', 'Бытовая техника', '', '', 'bytovaya-tehnika', '', 2, 1, ''),
(3, 2, 'Пылесосы', 'Пылесосы', 'Пылесосы', '', '', 'pylesosy', '', 3, 1, ''),
(4, 2, 'Миксеры', 'Миксеры', 'Миксеры', '', '', 'miksery', '', 4, 1, ''),
(5, 0, 'Фотоаппараты', 'Фотоаппараты', 'Фотоаппараты', '', '', 'fotoapparaty', '', 5, 1, '');

-- --------------------------------------------------------

--
-- Структура таблицы `s_categories_features`
--

DROP TABLE IF EXISTS `s_categories_features`;
CREATE TABLE IF NOT EXISTS `s_categories_features` (
  `category_id` int(11) NOT NULL,
  `feature_id` int(11) NOT NULL,
  PRIMARY KEY (`category_id`,`feature_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_categories_features`
--

INSERT INTO `s_categories_features` (`category_id`, `feature_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7),
(1, 8),
(1, 9),
(1, 10),
(1, 11),
(1, 12),
(1, 13),
(1, 14),
(1, 15),
(1, 16),
(1, 17),
(1, 18),
(1, 19),
(1, 20),
(1, 21),
(1, 22),
(1, 23),
(1, 24),
(1, 25),
(1, 26),
(1, 27),
(1, 28),
(1, 29),
(1, 30),
(1, 31),
(1, 32),
(1, 33),
(1, 34),
(1, 35),
(1, 36),
(1, 37),
(1, 38),
(1, 39),
(1, 40),
(1, 41),
(1, 42),
(1, 43),
(1, 44),
(1, 45),
(1, 46),
(1, 47),
(1, 48),
(1, 49),
(1, 50),
(1, 51),
(1, 52),
(1, 53),
(1, 54),
(1, 55),
(1, 56),
(1, 57),
(1, 58),
(1, 59),
(1, 60),
(1, 61),
(1, 62),
(1, 63),
(1, 64),
(1, 65),
(1, 66),
(1, 67),
(1, 68),
(1, 69),
(1, 70),
(1, 71),
(1, 72),
(3, 7),
(3, 73),
(3, 74),
(3, 75),
(3, 76),
(3, 77),
(3, 78),
(3, 79),
(3, 80),
(3, 81),
(3, 82),
(3, 83),
(3, 84),
(3, 85),
(3, 86),
(3, 87),
(3, 88),
(3, 89),
(4, 2),
(4, 6),
(4, 7),
(4, 83),
(4, 90),
(4, 91),
(4, 92),
(4, 93),
(4, 94),
(4, 95),
(4, 96),
(4, 97),
(4, 98),
(4, 99),
(5, 7),
(5, 25),
(5, 32),
(5, 35),
(5, 58),
(5, 83),
(5, 100),
(5, 101),
(5, 102),
(5, 103),
(5, 104),
(5, 105),
(5, 106),
(5, 107),
(5, 108),
(5, 109),
(5, 110),
(5, 111),
(5, 112),
(5, 113),
(5, 114),
(5, 115),
(5, 116),
(5, 117),
(5, 118),
(5, 119),
(5, 120),
(5, 121),
(5, 122),
(5, 123),
(5, 124),
(5, 125),
(5, 126),
(5, 127),
(5, 128),
(5, 129),
(5, 130),
(5, 131),
(5, 132),
(5, 133),
(5, 134),
(5, 135),
(5, 136),
(5, 137),
(5, 138),
(5, 139),
(5, 140),
(5, 141),
(5, 142),
(5, 143),
(5, 144),
(5, 145),
(5, 146),
(5, 147),
(5, 148);

-- --------------------------------------------------------

--
-- Структура таблицы `s_comments`
--

DROP TABLE IF EXISTS `s_comments`;
CREATE TABLE IF NOT EXISTS `s_comments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL DEFAULT '2014-10-31 08:03:55',
  `ip` varchar(20) NOT NULL,
  `object_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `type` enum('product','blog') NOT NULL,
  `approved` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `product_id` (`object_id`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_comments`
--

INSERT INTO `s_comments` (`id`, `date`, `ip`, `object_id`, `name`, `text`, `type`, `approved`) VALUES
(1, '2011-12-29 14:34:03', '127.0.0.1', 7, 'Иван', 'Отличный аппарат', 'product', 1),
(2, '2011-12-29 14:35:02', '127.0.0.1', 7, 'Игорь', 'Наушники идут в комплекте? Хорошие?', 'product', 1),
(3, '2011-12-29 14:36:57', '127.0.0.1', 29, 'Светлана', 'Работает у меня уже год, полёт нормальный', 'product', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `s_coupons`
--

DROP TABLE IF EXISTS `s_coupons`;
CREATE TABLE IF NOT EXISTS `s_coupons` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(256) NOT NULL,
  `expire` timestamp NULL DEFAULT NULL,
  `type` enum('absolute','percentage') NOT NULL DEFAULT 'absolute',
  `value` float(10,2) NOT NULL,
  `min_order_price` float(10,2) DEFAULT NULL,
  `single` int(1) NOT NULL DEFAULT '0',
  `usages` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_coupons`
--

INSERT INTO `s_coupons` (`id`, `code`, `expire`, `type`, `value`, `min_order_price`, `single`, `usages`) VALUES
(11, 'THANKYOU', '2015-05-31 21:00:00', 'absolute', 5.00, 50000.00, 1, 0),
(15, 'SIMPLACMS', NULL, 'absolute', 10.00, 150000.00, 0, 0),
(17, 'TESTCOUPON', '2010-05-31 21:00:00', 'percentage', 0.10, 0.00, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `s_currencies`
--

DROP TABLE IF EXISTS `s_currencies`;
CREATE TABLE IF NOT EXISTS `s_currencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '0',
  `sign` varchar(20) NOT NULL,
  `code` char(3) NOT NULL DEFAULT '',
  `rate_from` float(10,2) NOT NULL DEFAULT '1.00',
  `rate_to` float(10,2) NOT NULL DEFAULT '1.00',
  `cents` int(1) NOT NULL DEFAULT '2',
  `position` int(11) NOT NULL,
  `enabled` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `position` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_currencies`
--

INSERT INTO `s_currencies` (`id`, `name`, `sign`, `code`, `rate_from`, `rate_to`, `cents`, `position`, `enabled`) VALUES
(2, 'рубли', 'руб', 'RUR', 3.75, 3.75, 0, 1, 1),
(1, 'доллары', '$', 'USD', 1.00, 30.00, 2, 2, 1),
(3, 'вебмани wmz', 'wmz', 'WMZ', 0.15, 3.75, 2, 3, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `s_delivery`
--

DROP TABLE IF EXISTS `s_delivery`;
CREATE TABLE IF NOT EXISTS `s_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `free_from` float(10,2) NOT NULL,
  `price` float(10,2) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL,
  `separate_payment` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `position` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_delivery`
--

INSERT INTO `s_delivery` (`id`, `name`, `description`, `free_from`, `price`, `enabled`, `position`, `separate_payment`) VALUES
(1, 'Курьерская доставка по Москве', '<p><span>Курьерская доставка осуществляется на следующий день после оформления заказа, если товар есть в наличии. Курьерская доставка осуществляется в пределах Томска и Северска ежедневно с 10.00 до 21.00. Заказ на сумму свыше 300 рублей доставляется бесплатно.&nbsp;<br /><br />Стоимость бесплатной доставки раcсчитывается от суммы заказа с учтенной скидкой. В случае если сумма заказа после применения скидки менее 300р, осуществляется платная доставка.&nbsp;<br /><br />При сумме заказа менее 300 рублей стоимость доставки составляет от 50 рублей.</span></p>', 5000.00, 120.00, 1, 2, 1),
(2, 'Самовывоз', '<p>Удобный, бесплатный и быстрый способ получения заказа.</p><p>Адрес офиса: Адрес офиса: Москва, ул. Арбат, 1/3, офис 419</p>', 0.00, 0.00, 1, 3, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `s_delivery_payment`
--

DROP TABLE IF EXISTS `s_delivery_payment`;
CREATE TABLE IF NOT EXISTS `s_delivery_payment` (
  `delivery_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  PRIMARY KEY (`delivery_id`,`payment_method_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Связка способом оплаты и способов доставки';

--
-- Дамп данных таблицы `s_delivery_payment`
--

INSERT INTO `s_delivery_payment` (`delivery_id`, `payment_method_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7),
(1, 8),
(2, 1),
(2, 2),
(2, 3),
(2, 4),
(2, 5),
(2, 6),
(2, 7),
(2, 8),
(3, 1),
(3, 2),
(3, 3),
(3, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `s_features`
--

DROP TABLE IF EXISTS `s_features`;
CREATE TABLE IF NOT EXISTS `s_features` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `in_filter` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `position` (`position`),
  KEY `in_filter` (`in_filter`)
) ENGINE=MyISAM AUTO_INCREMENT=150 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_features`
--

INSERT INTO `s_features` (`id`, `name`, `position`, `in_filter`) VALUES
(1, 'Стандарт', 1, 0),
(2, 'Тип', 2, 1),
(3, 'Платформа', 3, 0),
(4, 'Операционная система', 4, 1),
(5, 'Тип корпуса', 5, 1),
(6, 'Материал корпуса', 6, 0),
(7, 'Вес', 7, 0),
(8, 'Размеры (ШxВxТ)', 8, 0),
(9, 'Тип экрана', 9, 0),
(10, 'Тип сенсорного экрана', 10, 0),
(11, 'Диагональ', 11, 0),
(12, 'Размер изображения', 12, 0),
(13, 'Автоматический поворот экрана', 13, 0),
(14, 'Тип мелодий', 14, 0),
(15, 'Виброзвонок', 15, 0),
(16, 'Фотокамера', 16, 0),
(17, 'Запись видеороликов', 17, 0),
(18, 'Макс. частота кадров видео', 18, 0),
(19, 'Воспроизведение видео', 19, 0),
(20, 'Аудио', 20, 0),
(21, 'Диктофон', 21, 0),
(22, 'Игры', 22, 0),
(23, 'Java-приложения', 23, 0),
(24, 'Разъем для наушников', 24, 0),
(25, 'Интерфейсы', 25, 0),
(26, 'Зарядка от USB', 26, 0),
(27, 'Встроенный GPS-приемник', 27, 0),
(28, 'Cистема A-GPS', 28, 0),
(29, 'Доступ в интернет', 29, 0),
(30, 'Синхронизация с компьютером', 30, 0),
(31, 'Использование в качестве USB-накопителя', 31, 0),
(32, 'Объем встроенной памяти', 32, 0),
(33, 'MMS', 33, 0),
(34, 'Тип аккумулятора', 34, 0),
(35, 'Емкость аккумулятора', 35, 0),
(36, 'Время разговора', 36, 0),
(37, 'Время ожидания', 37, 0),
(38, 'Громкая связь (встроенный динамик)', 38, 0),
(39, 'Режим полета', 39, 0),
(40, 'Датчики', 40, 0),
(41, 'Поиск по книжке', 41, 0),
(42, 'Обмен между SIM-картой и внутренней памятью', 42, 0),
(43, 'Органайзер', 43, 0),
(44, 'Комплектация', 44, 0),
(45, 'Дата анонсирования (г-м-д)', 45, 0),
(46, 'Русификация', 46, 0),
(47, 'Распознавание', 47, 0),
(48, 'Макс. разрешение видео', 48, 0),
(49, 'Geo Tagging', 49, 0),
(50, 'Фронтальная камера', 50, 0),
(51, 'Видеовыход', 51, 0),
(52, 'Модем', 52, 0),
(53, 'Объем постоянной памяти (ROM)', 53, 0),
(54, 'Процессор', 54, 0),
(55, 'Время работы в режиме прослушивания музыки', 55, 0),
(56, 'Управление', 56, 0),
(57, 'Автодозвон', 57, 0),
(58, 'Особенности', 58, 0),
(59, 'Поддержка DLNA', 59, 0),
(60, 'Объем оперативной памяти (RAM)', 60, 0),
(61, 'Дополнительные функции SMS', 61, 0),
(62, 'Профиль A2DP', 62, 0),
(63, 'Дата начала продаж (г-м-д)', 63, 0),
(64, 'QWERTY-клавиатура', 64, 0),
(65, 'VoIP-клиент', 65, 0),
(66, 'Push-To-Talk', 66, 0),
(67, 'Режимы кодирования звука HR, FR, EFR', 67, 0),
(68, 'Записная книжка в аппарате', 68, 0),
(69, 'Уровень SAR', 69, 0),
(70, 'Официальная поставка в Россию', 70, 0),
(71, 'Mobile Tracker', 71, 0),
(72, 'Поддержка двух SIM-карт', 72, 0),
(73, 'Уборка', 73, 0),
(74, 'Потребляемая мощность', 74, 0),
(75, 'Пылесборник', 75, 0),
(76, 'Регулятор мощности', 76, 0),
(77, 'Фильтр тонкой очистки', 77, 0),
(78, 'Источник питания', 78, 0),
(79, 'Уровень шума', 79, 0),
(80, 'Длина сетевого шнура', 80, 0),
(81, 'Функции и возможности', 81, 0),
(82, 'Размеры пылесоса (ШxГxВ)', 82, 0),
(83, 'Дополнительная информация', 83, 0),
(84, 'Труба всасывания', 84, 0),
(85, 'Возможность подключения электрощетки', 85, 0),
(86, 'Дополнительные насадки в комплекте', 86, 0),
(87, 'Турбощетка в комплекте', 87, 0),
(88, 'Мощность всасывания', 88, 0),
(89, 'Электрощетка в комплекте', 89, 0),
(90, 'Чаша', 90, 0),
(91, 'Мощность', 91, 0),
(92, 'Число скоростей', 92, 0),
(93, 'Дополнительные режимы', 93, 0),
(94, 'Количество насадок', 94, 0),
(95, 'Насадки', 95, 0),
(96, 'Кнопка отсоединения насадок', 96, 0),
(97, 'Защитная крышка на чашу', 97, 0),
(98, 'Прорезиненная ручка', 98, 0),
(99, 'Приспособление для хранения насадок', 99, 0),
(100, 'Общее число пикселов', 100, 0),
(101, 'Число эффективных пикселов', 101, 0),
(102, 'Физический размер', 102, 0),
(103, 'Кроп-фактор', 103, 0),
(104, 'Тип матрицы', 104, 0),
(105, 'Чувствительность', 105, 0),
(106, 'Баланс белого', 106, 0),
(107, 'Вспышка', 107, 0),
(108, 'Макросъёмка', 108, 0),
(109, 'Таймер', 109, 0),
(110, 'Время работы таймера', 110, 0),
(111, 'Формат кадра (фотосъемка)', 111, 0),
(112, 'Фокусное расстояние (35 мм эквивалент)', 112, 0),
(113, 'Оптический Zoom', 113, 0),
(114, 'Диафрагма', 114, 0),
(115, 'Видоискатель', 115, 0),
(116, 'ЖК-экран', 116, 0),
(117, 'Тип ЖК-экрана', 117, 0),
(118, 'Ручная настройка выдержки и диафрагмы', 118, 0),
(119, 'Экспокоррекция ', 119, 0),
(120, 'Минимальное расстояние съемки', 120, 0),
(121, 'Тип карт памяти', 121, 0),
(122, 'Форматы изображения', 122, 0),
(123, 'Формат аккумуляторов', 123, 0),
(124, 'Количество аккумуляторов', 124, 0),
(125, 'Запись видео', 125, 0),
(126, 'Формат записи видео', 126, 0),
(127, 'Максимальное разрешение роликов', 127, 0),
(128, 'Цифровой Zoom', 128, 0),
(129, 'Дополнительные возможности', 129, 0),
(130, 'Дата анонсирования', 130, 0),
(131, 'Дата начала продаж', 131, 0),
(132, 'Размер', 132, 0),
(133, 'Стабилизатор изображения (фотосъемка)', 133, 0),
(134, 'Режим серийной съемки', 134, 0),
(135, 'Подсветка автофокуса', 135, 0),
(136, 'Фокусировка по лицу', 136, 0),
(137, 'Разъем питания', 137, 0),
(138, 'Запись звука', 138, 0),
(139, 'Название объектива', 139, 0),
(140, 'Максимальная частота кадров видеоролика', 140, 0),
(141, 'Максимальная частота кадров при съемке HD-видео', 141, 0),
(142, 'Электронная стабилизация при видеосъемке', 142, 0),
(143, 'Скорость съемки', 143, 0),
(144, 'Число оптических элементов', 144, 0),
(145, 'Число групп оптических элементов', 145, 0),
(146, 'Выдержка', 146, 0),
(147, 'Замер экспозиции', 147, 0),
(148, 'Автоматическая обработка экспозиции', 148, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `s_feedbacks`
--

DROP TABLE IF EXISTS `s_feedbacks`;
CREATE TABLE IF NOT EXISTS `s_feedbacks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `ip` varchar(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `s_groups`
--

DROP TABLE IF EXISTS `s_groups`;
CREATE TABLE IF NOT EXISTS `s_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `discount` float(5,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_groups`
--

INSERT INTO `s_groups` (`id`, `name`, `discount`) VALUES
(1, 'Постоянный покупатель', 2.00);

-- --------------------------------------------------------

--
-- Структура таблицы `s_images`
--

DROP TABLE IF EXISTS `s_images`;
CREATE TABLE IF NOT EXISTS `s_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `product_id` int(11) NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `position` int(11) DEFAULT NULL,
  `name_original` varchar(255) DEFAULT NULL,
  `type_file` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `filename` (`filename`),
  KEY `product_id` (`product_id`),
  KEY `position` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=208 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_images`
--

INSERT INTO `s_images` (`id`, `name`, `product_id`, `filename`, `position`, `name_original`, `type_file`) VALUES
(5, '', 2, 'Samsung-GALAXY-S-II_1.jpg', 1, NULL, NULL),
(77, '', 1, 'iphone4s-white.jpeg', 0, NULL, NULL),
(78, '', 1, 'iphone4_2up_front_side.jpg', 1, NULL, NULL),
(84, '', 7, 'Sony-Ericsson-XPERIA-Arc.jpeg', 0, NULL, NULL),
(6, '', 2, 'g27.jpg', 2, NULL, NULL),
(7, '', 2, 'Samsung-Galaxy-S-II.jpg', 0, NULL, NULL),
(75, '', 3, 'HTC-Incredible-S_D.jpeg', 0, NULL, NULL),
(76, '', 3, 'htc-incredible-s.jpg', 1, NULL, NULL),
(80, '', 4, 'htc_sensation2.jpg', 1, NULL, NULL),
(18, '', 5, 'nokia_c5_03_image4462.jpg', 1, NULL, NULL),
(19, '', 5, 'nokia-c5-03-2.jpg', 2, NULL, NULL),
(82, '', 5, '210_Nokia_C5_03.jpeg', 0, NULL, NULL),
(81, '', 4, 'HTC-Sensation-4G-2.jpg', 2, NULL, NULL),
(79, '', 4, 'HTC-Sensation-4G-1.jpeg', 0, NULL, NULL),
(83, '', 6, 'E72_black_01-300-100.jpeg', 0, NULL, NULL),
(20, '', 6, 'E72_amethyst_front1_604x604.png', 1, NULL, NULL),
(28, '', 7, 'Sony-Ericsson-XPERIA-Arc.jpg', 1, NULL, NULL),
(21, '', 6, 'E72_topaz_front1_604x604.png', 2, NULL, NULL),
(27, '', 7, 'Xperia-ARC.png', 2, NULL, NULL),
(30, '', 8, 'Samsung_Galaxy_Mini_S5570_17.jpga1332ef1-c4d9-41cd-bade-164b5b0f001fLarge.jpg', 1, NULL, NULL),
(23, '', 6, 'Nokia-E72.jpg', 3, NULL, NULL),
(29, '', 8, 'Samsung-Galaxy-Mini-S5570.jpg', 0, NULL, NULL),
(36, '', 9, 'sony-ericsson-vivaz-mobile-phone.jpg', 2, NULL, NULL),
(42, '', 11, '11cfff01-be1c-42b0-92d1-942e6e5c1493.jpg', 1, NULL, NULL),
(31, '', 8, 'samsung_gt_s5570_galaxy_mini.jpg', 2, NULL, NULL),
(37, '', 9, 'Sony-Ericsson-Vivaz.jpg', 3, NULL, NULL),
(34, '', 9, 'Vivaz_Front_MoonSilver.jpg', 0, NULL, NULL),
(35, '', 9, 'sc001.jpg', 1, NULL, NULL),
(33, '', 8, 'ACA2DA021F31461C85ED84D6D8267E29.jpg', 3, NULL, NULL),
(43, '', 12, 'Nokia_E7_image1382.jpg', 2, NULL, NULL),
(38, '', 10, '10x0817iub2352nokia.jpg', 1, NULL, NULL),
(39, '', 10, '428_Ampliada.jpg', 2, NULL, NULL),
(40, '', 10, '1Nokia-X3-02-Touch-and-Type-1.jpg', 0, NULL, NULL),
(85, '', 11, 'nokia_X2_front_blue_604x604.png', 0, NULL, NULL),
(87, '', 13, 'nokiac600.jpg', 0, NULL, NULL),
(44, '', 12, 'black-and-silver-nokia-e7.jpg', 1, NULL, NULL),
(45, '', 12, 'nokia-e71.png', 3, NULL, NULL),
(48, '', 14, 'HTC-Salsa-412x500.jpg', 1, NULL, NULL),
(88, '', 14, 'htcsalsa_3.jpg', 0, NULL, NULL),
(49, '', 15, 'White-Blackberry-Torch-98001.jpg', 0, NULL, NULL),
(89, '', 17, 'Samsung-Diva-S7070.jpeg', 0, NULL, NULL),
(50, '', 16, 'legend_front-back-side_2.jpg', 1, NULL, NULL),
(58, '', 20, 'a270-e1302938698758.jpg', 0, NULL, NULL),
(51, '', 16, 'htc-legend.jpg', 0, NULL, NULL),
(56, '', 18, 'Blackberry-Bold-9900.jpg', 1, NULL, NULL),
(62, '', 22, 'fcb0349a.jpg', 0, NULL, NULL),
(55, '', 18, 'BlackBerry-Bold-9900-and-9930-Smartphone-2.jpg', 0, NULL, NULL),
(90, '', 19, 'xperia.jpg', 0, NULL, NULL),
(59, '', 21, 'Nokia-C2-031.jpg', 0, NULL, NULL),
(65, '', 25, 'Samsung_La_Fleur_Wave_GT-E2530-2.jpg', 0, NULL, NULL),
(60, '', 21, 'Nokia_C2-03-all.jpg', 1, NULL, NULL),
(63, '', 23, 'nokia-x6-16gb-pink-1.jpg', 0, NULL, NULL),
(61, '', 21, 'nokia-c2-03-dual-sim.jpg', 2, NULL, NULL),
(64, '', 24, 'samsung_s3650_corby_29193d.jpg', 0, NULL, NULL),
(66, '', 26, '1008.jpg', 0, NULL, NULL),
(68, '', 27, 'Torch_9810_Front2.jpg', 0, NULL, NULL),
(69, '', 28, 'nokia701_5.jpg', 0, NULL, NULL),
(86, '', 12, 'nokia_e7_blue_front_1200x1200.png', 0, NULL, NULL),
(91, '', 29, 'dc23_pink_weis_klein.jpeg', 0, NULL, NULL),
(94, '', 30, 'dyson_dc32_animal.jpg', 0, NULL, NULL),
(96, '', 32, 'u_00362479.jpg', 0, NULL, NULL),
(95, '', 31, 'zt3510uk-lr.jpeg', 0, NULL, NULL),
(97, '', 33, '231.jpg', 0, NULL, NULL),
(98, '', 34, 'Zelmer-481-67-2.jpg', 0, NULL, NULL),
(99, '', 35, '5900215513508F2.jpg', 0, NULL, NULL),
(101, '', 36, 'c_big1142293.jpg', 0, NULL, NULL),
(100, '', 36, '11430_3.jpg', 1, NULL, NULL),
(103, '', 38, 'nikon-l23-pink-1.jpg', 0, NULL, NULL),
(104, '', 39, 'Nikon-Coolpix-L120_1.jpg', 0, NULL, NULL),
(105, '', 40, 'wpid-nikon_coolpix_s2500_4501297245529-mamini2.jpg', 0, NULL, NULL),
(109, '', 41, 'canon-a3200-pink-1.jpg', 2, NULL, NULL),
(108, '', 41, 'canona3200is__56180.jpg', 1, NULL, NULL),
(110, '', 41, 'Canon-PowerShot-A3200-IS-Orange.jpg', 0, NULL, NULL),
(112, '', 42, 'IXUS-1000 HS BROWN.jpg', 0, NULL, NULL),
(174, 'MOK TreeBox 75 W TC_2', 67, 'MOK TreeBox 75 W TC_2.jpg', 0, 'MOK TreeBox 75 W TC_2', 'jpg'),
(172, 'ADT180T2', 62, 'ADT180T2.jpg', 0, 'ADT180T2', 'jpg'),
(201, 'Sigelei Mini Book TC 40W', 75, 'Sigelei Mini Book TC 40W.jpg', 0, 'Sigelei Mini Book TC 40W', 'jpg'),
(178, 'MOK TreeBox 75 W TC_1', 67, 'MOK TreeBox 75 W TC_1.jpg', 1, 'MOK TreeBox 75 W TC_1', 'jpg'),
(179, 'SMOK KOOPOR Plus 200W', 67, 'SMOK KOOPOR Plus 200W.jpg', 1, 'SMOK KOOPOR Plus 200W', 'jpg'),
(188, 'MOK TreeBox 75 W TC_3', 76, 'MOK TreeBox 75 W TC_3.jpg', 0, 'MOK TreeBox 75 W TC_3', 'jpg'),
(196, 'SMOK KOOPOR Plus 200W_1', 37, 'SMOK KOOPOR Plus 200W_1.jpg', 1, 'SMOK KOOPOR Plus 200W_1', 'jpg'),
(205, 'SMOK KOOPOR Plus 200W', 95, 'SMOK KOOPOR Plus 200W.jpg', 2, 'SMOK KOOPOR Plus 200W', 'jpg'),
(197, 'MOK TreeBox 75 W TC_1', 37, 'MOK TreeBox 75 W TC_1.jpg', 1, 'MOK TreeBox 75 W TC_1', 'jpg'),
(195, 'MOK TreeBox 75 W TC_2', 37, 'MOK TreeBox 75 W TC_2.jpg', 1, 'MOK TreeBox 75 W TC_2', 'jpg'),
(200, 'Sigelei Mini Book TC 40W_2', 75, 'Sigelei Mini Book TC 40W_2.jpg', 0, 'Sigelei Mini Book TC 40W_2', 'jpg'),
(202, 'Sigelei Mini Book TC 40W_1', 75, 'Sigelei Mini Book TC 40W_1.jpg', 1, 'Sigelei Mini Book TC 40W_1', 'jpg'),
(203, 'Sigelei Mini Book TC 40W_1', 75, 'Sigelei Mini Book TC 40W_1.jpg', 1, 'Sigelei Mini Book TC 40W_1', 'jpg1'),
(204, 'Sigelei Mini Book TC 40W_1', 75, 'Sigelei Mini Book TC 40W_1.jpg', 1, 'Sigelei Mini Book TC 40W_1', 'jpg'),
(206, 'MOK TreeBox 75 W TC_2', 95, 'MOK TreeBox 75 W TC_2.jpg', 2, 'MOK TreeBox 75 W TC_2', 'jpg'),
(207, 'MOK TreeBox 75 W TC', 95, 'MOK TreeBox 75 W TC.jpg', 2, 'MOK TreeBox 75 W TC', 'jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `s_labels`
--

DROP TABLE IF EXISTS `s_labels`;
CREATE TABLE IF NOT EXISTS `s_labels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `color` varchar(6) NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_labels`
--

INSERT INTO `s_labels` (`id`, `name`, `color`, `position`) VALUES
(4, 'перезвонить', 'ff00ff', 4),
(5, 'ожидается товар', '00d5fa', 5);

-- --------------------------------------------------------

--
-- Структура таблицы `s_menu`
--

DROP TABLE IF EXISTS `s_menu`;
CREATE TABLE IF NOT EXISTS `s_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `position` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_menu`
--

INSERT INTO `s_menu` (`id`, `name`, `position`) VALUES
(1, 'Основное меню', 1),
(2, 'Другие страницы', 2),
(4, 'Среднее меню', 1),
(3, 'Верхнее меню', 1),
(5, 'Меню в подвале', 1),
(6, 'Левое меню', 1),
(7, 'Правое меню', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `s_menu_link`
--

DROP TABLE IF EXISTS `s_menu_link`;
CREATE TABLE IF NOT EXISTS `s_menu_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(156) NOT NULL,
  `url` varchar(156) NOT NULL,
  `type_menu` int(25) NOT NULL,
  `active` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_menu_link`
--

INSERT INTO `s_menu_link` (`id`, `label`, `url`, `type_menu`, `active`, `parent_id`) VALUES
(22, 'Главная', '/', 3, 1, 0),
(23, 'Оплата', '/oplata', 3, 1, 0),
(24, 'Доставка', '/dostavka', 3, 1, 0),
(26, 'Статьи', '/articles/', 3, 1, 0),
(27, 'Контакты', '/contact', 6, 1, 0),
(28, 'Новости', '/news/', 3, 1, 0),
(29, 'Категории', '/category/', 3, 1, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `s_migration`
--

DROP TABLE IF EXISTS `s_migration`;
CREATE TABLE IF NOT EXISTS `s_migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_migration`
--

INSERT INTO `s_migration` (`version`, `apply_time`) VALUES
('m140506_102106_rbac_init', 1464949225);

-- --------------------------------------------------------

--
-- Структура таблицы `s_options`
--

DROP TABLE IF EXISTS `s_options`;
CREATE TABLE IF NOT EXISTS `s_options` (
  `product_id` int(11) NOT NULL,
  `feature_id` int(11) NOT NULL,
  `value` varchar(1024) NOT NULL,
  PRIMARY KEY (`product_id`,`feature_id`),
  KEY `value` (`value`(333)),
  KEY `product_id` (`product_id`),
  KEY `feature_id` (`feature_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_options`
--

INSERT INTO `s_options` (`product_id`, `feature_id`, `value`) VALUES
(5, 30, 'есть'),
(5, 29, 'WAP, GPRS, EDGE, HSDPA, HSUPA, POP/SMTP-клиент, IMAP4'),
(5, 28, 'есть'),
(5, 27, 'есть'),
(5, 26, 'есть'),
(5, 25, 'USB, Wi-Fi, Bluetooth'),
(5, 23, 'есть'),
(5, 24, '3.5 мм'),
(5, 22, 'есть'),
(5, 21, 'есть'),
(5, 20, 'MP3, AAC, WMA, FM-радиоприемник'),
(5, 19, 'MPEG-4, 3GPP'),
(5, 18, '15 кадров/с'),
(5, 17, 'есть'),
(5, 16, '5 млн пикс.'),
(5, 15, 'есть'),
(5, 14, '64-голосная полифония, MP3-мелодии'),
(5, 13, 'есть'),
(5, 12, '360x640 пикс.'),
(5, 11, '3.2 дюйма'),
(5, 10, 'резистивный'),
(1, 43, 'будильник, калькулятор, планировщик задач'),
(1, 40, 'освещенности, приближения, гироскоп, компас'),
(1, 37, '200 ч'),
(1, 38, 'есть'),
(1, 36, '14:00 ч:мин'),
(1, 34, 'Li-Ion'),
(1, 33, 'есть'),
(1, 30, 'есть'),
(1, 29, 'WAP, EDGE, HSDPA, HSUPA, POP/SMTP-клиент, HTML'),
(1, 28, 'есть'),
(1, 27, 'есть'),
(1, 26, 'есть'),
(1, 25, 'USB, Wi-Fi, Bluetooth 4.0'),
(1, 24, '3.5 мм'),
(1, 21, 'есть'),
(1, 20, 'MP3, AAC, WAV'),
(1, 18, '30 кадров/с'),
(1, 17, 'есть'),
(1, 15, 'есть'),
(1, 16, '8 млн пикс., 3264x2448, светодиодная вспышка'),
(1, 14, 'полифонические, MP3-мелодии'),
(1, 13, 'есть'),
(1, 12, '640x960 пикс.'),
(1, 11, '3.5 дюйма'),
(2, 40, 'освещенности, приближения, гироскоп, компас'),
(2, 39, 'есть'),
(2, 37, '350 ч'),
(2, 38, 'есть'),
(2, 36, '6:30 ч:мин'),
(2, 35, '1650 мАч'),
(2, 34, 'Li-Ion'),
(2, 33, 'есть'),
(2, 32, '16384 Мб'),
(2, 31, 'есть'),
(2, 30, 'есть'),
(2, 29, 'WAP, GPRS, EDGE, HSDPA, HSUPA, POP/SMTP-клиент'),
(2, 27, 'есть'),
(2, 28, 'есть'),
(2, 25, 'USB, Wi-Fi, Bluetooth 3.0'),
(2, 24, '3.5 мм'),
(2, 20, 'MP3, FM-радиоприемник'),
(2, 21, 'есть'),
(2, 15, 'есть'),
(2, 16, '8 млн пикс., 3264x2448, светодиодная вспышка'),
(2, 17, 'есть'),
(6, 43, 'будильник, калькулятор, планировщик задач, поддержка файлов MS Office'),
(6, 42, 'есть'),
(6, 40, 'освещенности, компас'),
(6, 41, 'есть'),
(6, 38, 'есть'),
(6, 37, '868 ч'),
(6, 35, '1500 мАч'),
(6, 36, '9:12 ч:мин'),
(6, 33, 'есть'),
(6, 34, 'Li-polymer'),
(6, 31, 'есть'),
(6, 30, 'есть'),
(6, 29, 'WAP 2.0, GPRS, HSCSD, EDGE, HSDPA, HSUPA, POP/SMTP-клиент, IMAP4, HTML'),
(6, 28, 'есть'),
(6, 27, 'есть'),
(6, 24, '3.5 мм'),
(6, 25, 'USB, Wi-Fi, Bluetooth 2.0'),
(6, 23, 'есть'),
(6, 22, 'есть'),
(6, 21, 'есть'),
(6, 20, 'MP3, AAC, WMA, FM-радиоприемник'),
(6, 19, 'MP4, AVC/H.264, WMV, RV, Flash Video, H.263, 3GPP'),
(6, 18, '15 кадров/с'),
(6, 17, 'есть'),
(6, 15, 'есть'),
(6, 16, '5 млн пикс., 2592x1944, светодиодная вспышка'),
(6, 11, '2.36 дюйма'),
(6, 12, '320x240 пикс.'),
(6, 14, '25-голосная полифония, MP3-мелодии'),
(7, 41, 'есть'),
(7, 40, 'освещенности, приближения'),
(7, 38, 'есть'),
(7, 39, 'есть'),
(7, 37, '430 ч'),
(7, 36, '7:00 ч:мин'),
(7, 35, '1500 мАч'),
(7, 34, 'смартфон/коммуникатор'),
(7, 33, 'есть'),
(7, 31, 'есть'),
(7, 30, 'есть'),
(7, 29, 'WAP, GPRS, EDGE, HSDPA, POP/SMTP-клиент'),
(7, 28, 'есть'),
(7, 27, 'есть'),
(7, 25, 'USB, Wi-Fi, Bluetooth'),
(7, 24, '3.5 мм'),
(7, 22, 'есть'),
(7, 21, 'есть'),
(7, 20, 'MP3, AAC, FM-радиоприемник'),
(7, 17, 'есть'),
(7, 16, '8.10 млн пикс., светодиодная вспышка'),
(7, 13, 'есть'),
(7, 14, 'полифонические, MP3-мелодии'),
(7, 15, 'есть'),
(7, 12, '480x854 пикс.'),
(8, 58, 'время работы в режиме разговора - до 570 мин. (2G), до 380 мин. (3G); время работы в режиме ожидания - до 570 ч (2G), до 440 ч (3G)'),
(8, 52, 'есть'),
(8, 47, 'улыбок'),
(8, 46, 'есть'),
(8, 45, '2011-01-26'),
(8, 43, 'будильник, калькулятор, планировщик задач'),
(8, 42, 'есть'),
(8, 41, 'есть'),
(8, 40, 'приближения, компас'),
(8, 36, '9:30 ч:мин'),
(8, 37, '570 ч'),
(8, 35, '1200 мАч'),
(8, 34, 'Li-Ion'),
(8, 33, 'есть'),
(8, 31, 'есть'),
(8, 30, 'есть'),
(9, 33, 'есть'),
(9, 32, '75 Мб'),
(9, 31, 'есть'),
(9, 30, 'есть'),
(9, 29, 'WAP, GPRS, EDGE, HSDPA, POP/SMTP-клиент, HTML'),
(9, 28, 'есть'),
(9, 25, 'USB, Wi-Fi, Bluetooth'),
(9, 27, 'есть'),
(9, 24, '3.5 мм'),
(9, 23, 'есть'),
(9, 20, 'MP3, FM-радиоприемник'),
(9, 17, 'есть'),
(9, 15, 'есть'),
(9, 16, '5.10 млн пикс., светодиодная вспышка'),
(9, 14, 'полифонические, MP3-мелодии'),
(9, 13, 'есть'),
(9, 12, '360x640 пикс.'),
(9, 11, '3.2 дюйма'),
(11, 37, '540 ч'),
(11, 36, '13:30 ч:мин'),
(11, 34, 'Li-Ion'),
(11, 35, '860 мАч'),
(11, 33, 'есть'),
(11, 32, '48 Мб'),
(11, 31, 'есть'),
(11, 29, 'WAP, GPRS, EDGE, POP/SMTP-клиент'),
(11, 30, 'есть'),
(11, 26, 'есть'),
(11, 25, 'USB, Bluetooth 2.1'),
(11, 24, '3.5 мм'),
(11, 23, 'есть'),
(11, 22, 'есть'),
(11, 21, 'есть'),
(11, 20, 'MP3, AAC, WMA, стереодинамики, FM-радиоприемник'),
(11, 19, 'MPEG-4, 3GPP'),
(11, 18, '20 кадров/с'),
(11, 17, 'есть (3GP)'),
(11, 16, '5 млн пикс., 2592x1944, светодиодная вспышка'),
(11, 15, 'есть'),
(14, 33, 'есть'),
(14, 32, '512 Мб'),
(14, 29, 'GPRS, EDGE, HSDPA'),
(14, 27, 'есть'),
(14, 26, 'есть'),
(14, 24, '3.5 мм'),
(14, 25, 'USB, Wi-Fi, Bluetooth 3.0'),
(14, 20, 'MP3, AAC, WAV, WMA'),
(14, 19, '3GP, 3G2, MP4, WMV, AVI, XVID'),
(14, 17, 'есть (3GP)'),
(14, 16, '5 млн пикс., встроенная вспышка'),
(14, 14, 'полифонические'),
(14, 13, 'есть'),
(14, 12, '320x480 пикс.'),
(14, 11, '3.4 дюйма'),
(14, 10, 'мультитач, емкостный'),
(15, 31, 'есть'),
(15, 29, 'WAP, GPRS, POP/SMTP-клиент'),
(15, 27, 'есть'),
(15, 24, '3.5 мм'),
(15, 25, 'USB, Wi-Fi, Bluetooth 2.1'),
(15, 20, 'MP3, AAC, WMA'),
(15, 17, 'есть'),
(15, 19, 'MPEG4, H.263, H.264, WMV3'),
(15, 16, '5 млн пикс., встроенная вспышка'),
(15, 15, 'есть'),
(15, 14, '32-голосная полифония, MP3-мелодии'),
(15, 13, 'есть'),
(15, 12, '360x480 пикс.'),
(15, 11, '3.2 дюйма'),
(15, 10, 'мультитач, емкостный'),
(17, 41, 'есть'),
(17, 21, 'есть'),
(17, 22, 'есть'),
(17, 23, 'есть'),
(17, 25, 'USB, Bluetooth 2.1'),
(17, 29, 'WAP 2.0, GPRS, EDGE, POP/SMTP-клиент, IMAP4, HTML'),
(17, 30, 'есть'),
(17, 31, 'есть'),
(17, 32, '50 Мб'),
(17, 33, 'есть'),
(17, 34, 'Li-Ion'),
(17, 35, '960 мАч'),
(17, 36, '8:00 ч:мин'),
(17, 37, '660 ч'),
(17, 38, 'есть'),
(17, 39, 'есть'),
(18, 32, '8192 Мб'),
(18, 29, 'WAP, GPRS, EDGE, HSDPA, POP/SMTP-клиент'),
(18, 28, 'есть'),
(18, 27, 'есть'),
(18, 25, 'USB, Wi-Fi, Bluetooth 2.1'),
(18, 23, 'есть'),
(18, 24, '3.5 мм'),
(18, 22, 'есть'),
(18, 21, 'есть'),
(18, 20, 'MP3, AAC, WMA'),
(18, 19, 'MPEG4, WMV'),
(18, 17, 'есть'),
(18, 16, '5 млн пикс., 2592x1944, встроенная вспышка'),
(18, 15, 'есть'),
(18, 14, 'полифонические, MP3-мелодии'),
(18, 13, 'есть'),
(18, 12, '640x480 пикс.'),
(18, 11, '2.8 дюйма'),
(18, 10, 'мультитач, емкостный'),
(18, 9, 'цветной TFT, 16.78 млн цветов, сенсорный'),
(18, 8, '66x115x11 мм'),
(18, 6, 'металл и пластик'),
(18, 7, '130 г'),
(18, 5, 'классический'),
(18, 4, 'BlackBerry OS'),
(18, 3, 'BlackBerry OS'),
(18, 2, 'смартфон/коммуникатор'),
(18, 1, 'GSM 900/1800/1900, 3G (UMTS)'),
(21, 35, '1020 мАч'),
(21, 34, 'Li-Ion'),
(21, 33, 'есть'),
(21, 32, '10 Мб'),
(21, 29, 'WAP, GPRS, EDGE, POP/SMTP-клиент'),
(21, 25, 'USB, Bluetooth 2.1'),
(21, 24, '3.5 мм'),
(21, 23, 'есть'),
(21, 20, 'MP3, AAC, WAV, FM-радиоприемник'),
(21, 18, '15 кадров/с'),
(21, 17, 'есть (3GP)'),
(21, 16, '2 млн пикс.'),
(21, 15, 'есть'),
(21, 14, 'полифонические, MP3-мелодии'),
(21, 12, '240x320 пикс.'),
(21, 11, '2.6 дюйма'),
(22, 31, 'есть'),
(22, 25, 'USB, Wi-Fi, Bluetooth 2.1'),
(22, 29, 'WAP, GPRS, EDGE, POP/SMTP-клиент'),
(22, 24, '3.5 мм'),
(22, 23, 'есть'),
(22, 21, 'есть'),
(22, 19, 'MPEG4'),
(22, 20, 'MP3, FM-радиоприемник'),
(22, 17, 'есть (MPEG4)'),
(22, 16, '2 млн пикс.'),
(22, 15, 'есть'),
(22, 14, '64-голосная полифония, MP3-мелодии'),
(22, 12, '320x240 пикс.'),
(22, 11, '2.4 дюйма'),
(26, 44, 'телефон, батарея Nokia BL-6Q, карта памяти SD 1Гб, гарнитура µUSB Nokia WH-203, кабель для подключения к компьютеру Nokia CA-101, зарядное устройство Nokia AC-8E, чехол (коллекция Illuvial), ремешок (коллекция Illuvial), руководство'),
(26, 43, 'будильник, калькулятор, планировщик задач'),
(26, 42, 'есть'),
(26, 41, 'есть'),
(26, 40, 'освещенности'),
(26, 39, 'есть'),
(26, 38, 'есть'),
(26, 37, '416 ч'),
(26, 36, '5:00 ч:мин'),
(26, 35, '960 мАч'),
(26, 34, 'Li-Ion'),
(26, 32, '170 Мб'),
(26, 33, 'есть'),
(26, 30, 'есть'),
(26, 29, 'WAP, GPRS, EDGE, HSDPA, HSUPA, POP/SMTP-клиент, IMAP4'),
(26, 28, 'есть'),
(26, 27, 'есть'),
(26, 26, 'есть'),
(26, 25, 'USB, Bluetooth 2.1'),
(26, 23, 'есть'),
(26, 21, 'есть'),
(26, 20, 'MP3, AAC, WMA, FM-радиоприемник'),
(26, 18, '30 кадров/с'),
(26, 19, '.mp4, .3gp'),
(26, 15, 'есть'),
(26, 16, '5 млн пикс., 2592x1944, светодиодная вспышка'),
(26, 17, 'есть (.mp4, .3gp)'),
(27, 35, '1270 мАч'),
(27, 34, 'Li-Ion'),
(27, 33, 'есть'),
(27, 32, '8192 Мб'),
(27, 29, 'WAP, GPRS, EDGE, HSDPA, HSUPA, POP/SMTP-клиент'),
(27, 25, 'USB, Wi-Fi, Bluetooth 2.1'),
(27, 27, 'есть'),
(27, 24, '3.5 мм'),
(27, 20, 'MP3, AAC, WAV, WMA'),
(27, 19, 'MP4, M4A, 3GP, M4V, AVI, ASF, WMV'),
(27, 17, 'есть'),
(27, 16, '5 млн пикс., встроенная вспышка'),
(27, 15, 'есть'),
(27, 14, 'полифонические, MP3-мелодии'),
(27, 13, 'есть'),
(27, 12, '480x640 пикс.'),
(27, 11, '3.2 дюйма'),
(27, 10, 'смартфон/коммуникатор'),
(28, 25, 'USB, Wi-Fi, Bluetooth 3.0'),
(28, 26, 'есть'),
(28, 27, 'есть'),
(28, 28, 'есть'),
(28, 29, 'WAP, GPRS, EDGE, HSDPA, HSUPA, POP/SMTP-клиент, IMAP4'),
(28, 30, 'есть'),
(28, 31, 'есть'),
(28, 32, '8192 Мб'),
(28, 33, 'есть'),
(28, 34, 'Li-Ion'),
(28, 35, '1300 мАч'),
(28, 36, '17:00 ч:мин'),
(28, 37, '504 ч'),
(28, 38, 'есть'),
(28, 40, 'освещенности, приближения, компас'),
(28, 43, 'будильник, калькулятор, планировщик задач'),
(28, 44, 'телефон, батарея BL-5K, стерео гарнитура Nokia WH-207, дата кабель Nokia CA-179, зарядное устройство Nokia AC-15, инструкция'),
(28, 45, '2011-08-25'),
(28, 46, 'есть'),
(28, 47, 'лиц, улыбок'),
(28, 48, '1280x720'),
(28, 51, 'TV-выход'),
(28, 52, 'есть'),
(28, 55, '71 ч'),
(28, 58, 'яркость дисплея - 1000 нит; технологии IPS и ClearBlack; дисплей защищен стеклом Corning Gorilla Glass'),
(28, 61, 'ввод текста со словарем'),
(29, 84, 'телескопическая'),
(29, 85, 'есть'),
(29, 86, 'пол/ковер; щелевая; для чистки полированных поверхностей; для чистки мягкой мебели; гибкая щелевая; для чистки матрасов; щетка с жесткой щетиной'),
(29, 82, '35.2x46x28.9 cм'),
(29, 83, 'радиус действия 10м; прорезиненные колеса; убивает бактерии и аллергены'),
(31, 83, 'мягкие колеса; радиус действия 9м; индикатор загрязнения фильтра'),
(30, 82, '30.2x49.1x35.2 cм'),
(30, 83, 'HEPA фильтр с антибактериальным экраном Bactisafe задерживает и убивает бактерии и аллергены; радиус действия 10 м; прорезиненные колеса'),
(31, 76, 'на корпусе'),
(31, 77, 'есть'),
(31, 78, 'сеть'),
(31, 79, '85 дБ'),
(31, 80, '6 м'),
(31, 81, ' автосматывание сетевого шнура,  ножной переключатель вкл./выкл. на корпусе,  вертикальная парковка трубы всасывания на корпусе пылесоса'),
(31, 82, '30.2x39x30 cм'),
(32, 83, 'радиус действия 8.6м, гигиеничная очистка контейнера, колеса прорезиненные'),
(32, 82, '26.3x40.2x29.1 cм'),
(32, 80, '5 м'),
(32, 81, 'индикатор заполнения пылесборника,  автосматывание сетевого шнура,  вертикальная парковка трубы всасывания на корпусе пылесоса'),
(32, 79, '82 дБ'),
(32, 76, 'на корпусе'),
(32, 77, 'есть'),
(32, 78, 'сеть'),
(33, 76, 'нет'),
(33, 77, 'есть'),
(33, 78, 'сеть'),
(33, 79, '85 дБ'),
(33, 80, '6.5 м'),
(33, 81, ' автосматывание сетевого шнура,  ножной переключатель вкл./выкл. на корпусе, место для хранения насадок'),
(33, 82, '30.1x49x35.2 cм'),
(30, 81, ' автосматывание сетевого шнура,  ножной переключатель вкл./выкл. на корпусе, обеззараживающая УФ-лампа, место для хранения насадок'),
(30, 78, 'сеть'),
(30, 79, '84 дБ'),
(30, 80, '6.5 м'),
(33, 83, 'радиус действия 10 м; прорезиненные колеса'),
(34, 94, '4'),
(34, 95, 'венчик для взбивания, крюки для теста, блендер'),
(34, 91, '400 Вт'),
(34, 92, '5'),
(34, 93, 'турбо'),
(35, 7, '2.3 кг'),
(35, 90, 'вращающаяся, 3 л, пластик'),
(35, 91, '400 Вт'),
(35, 92, '5'),
(35, 93, 'турбо'),
(35, 95, 'венчик для взбивания, крюки для теста'),
(35, 96, 'есть'),
(36, 95, 'венчик для взбивания, крюки для теста'),
(36, 94, '2'),
(36, 93, 'турбо'),
(36, 92, '5'),
(36, 7, '1 кг'),
(36, 91, '400 Вт'),
(37, 108, 'есть'),
(37, 109, 'есть'),
(37, 110, '2, 10 c'),
(37, 111, '4:3, 16:9'),
(37, 112, '28 - 140 мм'),
(37, 113, '5x'),
(37, 114, 'F3.9 - F4.8'),
(37, 115, 'отсутствует'),
(37, 116, '820000 пикселов, 3.50 дюйма'),
(37, 117, 'сенсорный'),
(37, 118, 'нет'),
(37, 119, '+/- 2 EV с шагом 1/3 ступени'),
(37, 120, '0.01 м'),
(37, 121, 'SD, SDHC, SDXC'),
(37, 122, 'JPEG'),
(37, 123, 'свой собственный'),
(37, 124, '1'),
(37, 125, 'есть'),
(38, 104, 'СCD'),
(38, 105, '80 - 1600 ISO, Auto ISO'),
(38, 106, 'автоматический, из списка'),
(38, 107, 'встроенная, подавление эффекта красных глаз'),
(38, 108, 'есть'),
(38, 109, 'есть'),
(38, 112, '28 - 140 мм'),
(38, 113, '5x'),
(38, 114, 'F2.7 - F6.8'),
(38, 115, 'отсутствует'),
(38, 116, '230000 пикселов, 2.70 дюйма'),
(38, 117, '230000 пикселов, 2.70 дюйма'),
(38, 118, 'нет'),
(38, 119, '+/- 2 EV с шагом 1/3 ступени'),
(38, 120, '0.03 м'),
(38, 121, 'SD, SDHC, SDXC'),
(38, 122, 'JPEG'),
(38, 123, 'AA-совмеcтимый'),
(38, 124, '2'),
(38, 125, 'есть'),
(38, 127, '3648 x 2736'),
(38, 129, 'крепление для штатива, cъемка HDR'),
(38, 132, '93x60x30 мм'),
(38, 133, 'цифровой'),
(38, 134, 'есть'),
(39, 119, '+/- 2 EV с шагом 1/3 ступени'),
(39, 120, '0.01 м'),
(39, 117, '921000 пикселов, 3 дюйма'),
(39, 118, 'нет'),
(39, 116, '921000 пикселов, 3 дюйма'),
(39, 115, 'отсутствует'),
(39, 114, 'F3.1 - F5.8'),
(39, 113, '21x'),
(39, 112, '25 - 525 мм'),
(39, 111, '4:3, 16:9'),
(39, 110, '2, 10 c'),
(39, 109, 'есть'),
(39, 108, 'есть'),
(39, 107, 'встроенная, подавление эффекта красных глаз'),
(39, 106, 'автоматический, ручная установка, из списка'),
(40, 132, '93x57x20 мм'),
(40, 130, '2011-02-08'),
(40, 129, 'крепление для штатива'),
(40, 128, '4x'),
(40, 127, '640x480'),
(40, 125, 'есть'),
(40, 124, '1'),
(40, 123, 'свой собственный'),
(40, 122, 'JPEG'),
(40, 120, '0.08 м'),
(40, 121, 'SD, SDHC, SDXC'),
(40, 119, '+/- 2 EV с шагом 1/3 ступени'),
(40, 118, 'нет'),
(40, 117, '230000 пикселов, 2.70 дюйма'),
(40, 106, 'автоматический, из списка'),
(40, 107, 'встроенная, подавление эффекта красных глаз'),
(40, 108, 'есть'),
(40, 109, 'есть'),
(40, 110, '2, 10 c'),
(40, 111, '4:3, 16:9'),
(40, 112, '27 - 108 мм'),
(40, 113, '4x'),
(40, 114, 'F3.2 - F5.9'),
(40, 115, 'отсутствует'),
(40, 116, '230000 пикселов, 2.70 дюйма'),
(41, 108, 'есть'),
(41, 109, 'есть'),
(41, 110, '2, 10 c'),
(41, 111, '4:3, 16:9'),
(41, 112, '28 - 140 мм'),
(41, 113, '5x'),
(41, 114, 'F2.8 - F5.9'),
(41, 115, 'отсутствует'),
(41, 116, '230400 пикселов, 2.70 дюйма'),
(41, 117, '230400 пикселов, 2.70 дюйма'),
(41, 118, 'нет'),
(41, 119, '+/- 2 EV с шагом 1/3 ступени'),
(41, 120, '0.03 м'),
(41, 121, 'SD, SDHC, SDXC, MMCPlus, HC MMCPlus'),
(41, 122, 'JPEG'),
(41, 123, 'свой собственный'),
(41, 124, '1'),
(41, 125, 'есть'),
(41, 126, 'MOV'),
(41, 127, '1280x720'),
(41, 128, '4x'),
(41, 129, 'крепление для штатива, датчик ориентации'),
(41, 132, '95x57x24 мм'),
(41, 133, 'оптический, подвижный элемент в объективе'),
(41, 135, 'есть'),
(41, 136, 'есть'),
(41, 138, 'есть'),
(41, 140, '30 кадров/с'),
(41, 141, '30 кадров/с при разрешении 1280x720'),
(41, 143, '0.9 кадр./сек'),
(41, 144, '7'),
(41, 145, '6'),
(41, 146, '15 - 1/1600 с'),
(41, 147, 'центровзвешенный, общий (Evaluative), точечный'),
(29, 80, '6.5 м'),
(29, 81, ' автосматывание сетевого шнура,  ножной переключатель вкл./выкл. на корпусе, место для хранения насадок'),
(37, 107, 'встроенная, подавление эффекта красных глаз'),
(37, 106, 'автоматический, ручная установка, из списка'),
(37, 105, '125 - 3200 ISO, Auto ISO'),
(42, 108, 'есть'),
(42, 109, 'есть'),
(42, 110, '2, 10 c'),
(42, 111, '4:3, 16:9'),
(42, 112, '36 - 360 мм'),
(42, 113, '10x'),
(42, 114, 'F3.4 - F5.6'),
(42, 115, 'отсутствует'),
(42, 116, '230000 пикселов, 3 дюйма'),
(42, 117, '230000 пикселов, 3 дюйма'),
(42, 118, 'нет'),
(42, 119, '+/- 2 EV с шагом 1/3 ступени'),
(42, 120, '0.01 м'),
(42, 121, 'SD, SDHC, SDXC, MMCPlus, HC MMCPlus'),
(42, 122, '2 JPEG'),
(42, 123, 'свой собственный'),
(42, 124, '1'),
(42, 125, 'есть'),
(42, 126, 'MOV'),
(42, 127, '1920x1080'),
(42, 128, '4x'),
(42, 129, 'крепление для штатива'),
(42, 130, '2010-08-19'),
(42, 131, '2010-09-01'),
(42, 132, '101x59x22 мм'),
(42, 133, 'оптический, подвижный элемент в объективе'),
(42, 135, 'есть'),
(42, 136, 'есть'),
(42, 138, 'есть'),
(42, 140, '30 кадров/с'),
(42, 141, '30 кадров/с при разрешении 1280x720, 24 кадров/с при разрешении 1920x1080'),
(42, 143, '8.8 кадр./сек'),
(42, 144, '14'),
(42, 145, '12'),
(42, 146, '15 - 1/4000 с'),
(42, 147, 'центровзвешенный, общий (Evaluative), точечный'),
(42, 148, 'с приоритетом затвора, с приоритетом диафрагмы'),
(37, 126, 'MOV'),
(39, 121, 'SD, SDHC, SDXC'),
(39, 122, 'JPEG'),
(39, 123, 'AA-совмеcтимый'),
(39, 124, '4'),
(39, 125, 'есть'),
(39, 127, '1280x720'),
(39, 128, '4x'),
(39, 129, 'крепление для штатива'),
(39, 130, '2011-02-08'),
(39, 131, '2011-02-15'),
(39, 132, '110x77x78 мм'),
(39, 133, 'двойной, сдвиг матрицы'),
(39, 134, 'есть'),
(2, 47, 'лиц'),
(2, 41, 'есть'),
(2, 42, 'есть'),
(2, 43, 'будильник, калькулятор, планировщик задач'),
(2, 44, 'телефон, аккумулятор, проводная стереогарнитура, USB-кабель, зарядное устройство'),
(2, 45, '2011-02-14'),
(2, 46, 'есть'),
(17, 20, 'MP3, AAC, WMA, FM-радиоприемник'),
(17, 18, '15 кадров/с'),
(17, 17, 'есть (H.263, MPEG4)'),
(17, 16, '3.20 млн пикс., 2048x1536'),
(17, 15, 'есть'),
(65, 12, '240x320 пикс.'),
(65, 13, 'есть'),
(65, 14, 'полифонические, MP3-мелодии'),
(65, 15, 'есть'),
(65, 16, '3 млн пикс.'),
(65, 17, 'есть (MPEG4)'),
(65, 18, '15 кадров/с'),
(65, 20, 'MP3, AAC, FM-радиоприемник'),
(8, 21, 'есть'),
(8, 24, '3.5 мм'),
(8, 25, 'USB, Wi-Fi, Bluetooth 2.1'),
(8, 27, 'есть'),
(8, 28, 'есть'),
(8, 29, 'WAP, GPRS, EDGE, HSDPA, POP/SMTP-клиент, IMAP4'),
(1, 46, 'есть'),
(1, 47, 'лиц'),
(1, 48, '1920x1080'),
(1, 49, 'есть'),
(1, 50, 'есть, 0.3 млн пикс.'),
(1, 51, 'TV-выход'),
(1, 52, 'есть'),
(1, 53, '16384 Мб'),
(1, 54, 'Apple A5, двухъядерный'),
(1, 55, '40 ч'),
(1, 56, 'голосовой набор, голосовое управление'),
(1, 57, 'есть'),
(2, 14, 'полифонические, MP3-мелодии'),
(2, 13, 'есть'),
(2, 12, 'число строк - 16, 480x800 пикс.'),
(2, 11, '4.27 дюйма'),
(2, 10, 'мультитач, емкостный'),
(2, 8, '66.1x125.3x8.49 мм'),
(2, 9, 'цветной Super AMOLED Plus, 16.78 млн цветов, сенсорный'),
(2, 4, 'Android 2.3'),
(2, 5, 'классический'),
(2, 6, 'металл и пластик'),
(2, 7, '116 г'),
(17, 42, 'есть'),
(17, 43, 'будильник, калькулятор, планировщик задач'),
(17, 44, 'телефон, аккумулятор, зарядное устройство, чехол, проводная стереогарнитура, инструкция'),
(17, 62, 'есть'),
(17, 48, '320x240'),
(17, 61, 'шаблоны сообщений'),
(5, 31, 'есть'),
(5, 32, '40 Мб'),
(5, 33, 'есть'),
(5, 34, 'Li-Ion'),
(5, 35, '1000 мАч'),
(5, 36, '11:30 ч:мин'),
(5, 37, '600 ч'),
(5, 38, 'есть'),
(5, 39, 'есть'),
(5, 40, 'компас'),
(5, 41, 'есть'),
(5, 42, 'есть'),
(5, 43, 'будильник, калькулятор, планировщик задач'),
(5, 44, 'телефон, аккумулятор BL-4U, зарядное устройство AC-8/AC-15, стерео гарнитура WH-102, соединительный кабель CA-101D, карта памяти 2Gb microSD MU-37, инструкция'),
(6, 48, '640x480'),
(6, 50, 'есть'),
(6, 44, 'телефон, зарядное устройство AC-8, MicroSD4GB MU-41, MicroUSB-кабель CA-101, стереогарнитура WH-601, аккумулятор BP-4L, чехол и ремешок, ткань для протирания, инструкция'),
(6, 52, 'есть'),
(6, 55, '41 ч'),
(6, 56, 'голосовое управление'),
(6, 57, 'есть'),
(6, 61, 'ввод текста со словарем, шаблоны сообщений, отправка SMS нескольким адресатам'),
(7, 52, 'есть'),
(7, 42, 'есть'),
(7, 43, 'будильник, калькулятор, планировщик задач, поддержка файлов MS Office'),
(7, 44, 'телефон, батарея, стереогарнитура, кабель micro USB'),
(7, 45, '2011-01-06'),
(7, 46, 'есть'),
(7, 47, 'лиц, улыбок'),
(7, 48, '1280x720'),
(7, 49, 'есть'),
(7, 51, 'TV-выход, HDMI'),
(9, 34, 'смартфон/коммуникатор'),
(9, 36, '12:30 ч:мин'),
(9, 37, '440 ч'),
(9, 38, 'есть'),
(9, 39, 'есть'),
(9, 41, 'есть'),
(9, 42, 'есть'),
(9, 43, 'будильник, калькулятор, планировщик задач'),
(9, 44, 'телефон, батарея, стереогарнитура, карта памяти MicroSD 8Gb, кабель microUSB'),
(9, 45, '2010-02-14'),
(11, 38, 'есть'),
(11, 39, 'есть'),
(11, 41, 'есть'),
(11, 42, 'есть'),
(11, 43, 'калькулятор, планировщик задач'),
(11, 44, 'телефон, батарея Nokia BL-4C, компактное зарядное устройство Nokia AC-3, стереогарнитура Nokia WH-205, кабель для подключения Nokia CA-101D, карта памяти microSDHC 2 Гб, руководство пользователя'),
(11, 46, 'есть'),
(14, 34, 'Li-Ion'),
(14, 35, '1520 мАч'),
(14, 36, '9:45 ч:мин'),
(14, 37, '465 ч'),
(14, 40, 'освещенности, приближения, компас'),
(14, 43, 'будильник, калькулятор, планировщик задач'),
(14, 50, 'есть, 0.3 млн пикс.'),
(15, 33, 'есть'),
(15, 34, 'Li-Ion'),
(15, 35, '1300 мАч'),
(15, 36, '5:48 ч:мин'),
(15, 37, '432 ч'),
(15, 38, 'есть'),
(15, 41, 'есть'),
(15, 42, 'есть'),
(15, 43, 'будильник, калькулятор, планировщик задач'),
(15, 48, '640x480'),
(15, 49, 'есть'),
(18, 33, 'есть'),
(18, 34, 'Li-Ion'),
(18, 35, '1230 мАч'),
(18, 38, 'есть'),
(18, 40, 'освещенности, приближения, компас'),
(18, 41, 'есть'),
(18, 42, 'есть'),
(18, 43, 'будильник, калькулятор, планировщик задач'),
(18, 45, '2011-05-02'),
(18, 46, 'есть'),
(18, 47, 'лиц'),
(18, 48, '1280x720'),
(18, 49, 'есть'),
(18, 56, 'голосовой набор'),
(18, 60, '768 Мб'),
(18, 61, 'ввод текста со словарем'),
(18, 62, 'есть'),
(18, 63, '2011-07-01'),
(18, 64, 'есть'),
(21, 36, '5:00 ч:мин'),
(21, 37, '400 ч'),
(21, 39, 'есть'),
(21, 43, 'будильник, калькулятор, планировщик задач'),
(21, 44, 'телефон, батарея, зарядное устройство, стерео гарнитура, карта памяти MicroSD 2 Гб, инструкция'),
(21, 45, '2011-06-21'),
(22, 32, '60 Мб'),
(22, 33, 'есть'),
(22, 34, 'Li-Ion'),
(22, 36, '12:00 ч:мин'),
(22, 37, '520 ч'),
(22, 41, 'есть'),
(22, 42, 'есть'),
(22, 43, 'будильник, калькулятор, планировщик задач'),
(26, 58, 'технология Content Adaptive Brightness Control (CABC), выделенная клавиша управления камерой'),
(26, 46, 'есть'),
(26, 48, '640x480'),
(26, 56, 'голосовой набор'),
(27, 36, '6:30 ч:мин'),
(27, 37, '307 ч'),
(27, 38, 'есть'),
(27, 40, 'освещенности, приближения, компас'),
(27, 42, 'есть'),
(27, 43, 'будильник, калькулятор, планировщик задач'),
(27, 47, 'лиц'),
(27, 48, '1280x720'),
(27, 49, 'есть'),
(27, 52, 'есть'),
(27, 55, '54 ч'),
(28, 24, '3.5 мм'),
(28, 23, 'есть'),
(28, 21, 'есть'),
(28, 20, 'MP3, AAC, WMA, FM-радиоприемник, FM-трансмиттер'),
(28, 19, 'MPEG-4 , H.264/AVC, H.263/3GPP, RealVideo 8/9/10'),
(28, 17, 'есть'),
(28, 15, 'есть'),
(28, 16, '8 млн пикс., светодиодная вспышка'),
(36, 6, 'пластик'),
(36, 2, 'ручной'),
(31, 84, 'телескопическая'),
(31, 86, 'пол/ковер; для мягкой мебели'),
(34, 90, 'вращающаяся, 3 л, пластик'),
(34, 83, 'весы с LCD дисплеем с подсветкой, насадка для протирания'),
(35, 6, 'пластик'),
(35, 2, 'стационарный'),
(33, 84, 'телескопическая'),
(33, 86, 'пол/ковер; с жесткой щетиной; для мягкой мебели; щелевая; матрасная'),
(30, 84, 'телескопическая'),
(30, 86, 'щелевая; для полированных поверхностей; для мягкой мебели; щетка для твердых поверхностей; мини-турбо'),
(32, 84, 'телескопическая'),
(32, 85, 'есть'),
(32, 86, 'щелевая; для мебели; щетка для твердых покрытий'),
(35, 98, 'есть'),
(36, 96, 'есть'),
(36, 97, 'нет'),
(36, 99, 'нет'),
(65, 11, '3.14 дюйма'),
(65, 10, 'смартфон/коммуникатор'),
(65, 9, 'цветной, сенсорный'),
(65, 8, '58.6x115.2x9.3 мм'),
(65, 4, 'iOS 5'),
(65, 5, 'классический'),
(65, 6, 'металл и пластик'),
(65, 2, 'телефон'),
(65, 1, 'GSM 900/1800/1900, 3G (UMTS)'),
(8, 59, 'есть'),
(8, 61, 'шаблоны сообщений'),
(1, 10, 'мультитач, емкостный'),
(1, 9, 'цветной, сенсорный'),
(1, 8, '58.6x115.2x9.3 мм'),
(1, 7, '1 кг'),
(1, 6, 'сталь и стекло'),
(1, 1, 'GSM 900/1800/1900, CDMA 800, CDMA 1900, 3G (UMTS), EV-DO Rev. A'),
(1, 2, 'смартфон/коммуникатор'),
(1, 4, 'мокрая курица'),
(1, 5, '1500 Вт'),
(1, 58, 'технология AirPlay, iCloud; 2 антенны; время разговора - 480 мин (3G), 840 мин (2G GSM); технология экрана - Retina Display; расцветка - черный, белый'),
(17, 14, '64-голосная полифония, MP3-мелодии'),
(17, 12, '240x320 пикс.'),
(17, 11, '2.8 дюйма'),
(17, 10, 'резистивный'),
(17, 7, '94 г'),
(17, 8, '55x101x13 мм'),
(17, 9, 'цветной TFT, 16.78 млн цветов, сенсорный'),
(17, 6, 'пластик'),
(17, 5, 'классический'),
(17, 2, 'телефон'),
(17, 1, 'GSM 900/1800/1900'),
(17, 68, '1000 номеров'),
(17, 69, '0.993'),
(17, 71, 'есть'),
(2, 48, '1920x1080'),
(2, 49, 'есть'),
(2, 50, 'есть, 2 млн пикс.'),
(2, 51, 'TV-выход'),
(2, 52, 'есть'),
(2, 54, 'ARM Cortex-A9, 1200 МГц, двухъядерный'),
(2, 55, '30 ч'),
(2, 56, 'голосовой набор, голосовое управление'),
(2, 58, 'поддерживается функция USB on the Go (с помощью  переходника к microUSB-разъему можно подключать флешки или жесткие диски)'),
(2, 59, 'есть'),
(2, 60, '1024 Мб'),
(2, 2, 'смартфон/коммуникатор'),
(2, 1, 'GSM 900/1800/1900, 3G (UMTS)'),
(2, 61, 'шаблоны сообщений'),
(2, 62, 'есть'),
(2, 63, '2011-05-18'),
(5, 9, 'цветной, 16.78 млн цветов, сенсорный'),
(5, 8, '51x106x14 мм'),
(5, 6, 'пластик'),
(5, 7, '93 г'),
(5, 2, 'смартфон/коммуникатор'),
(5, 3, 'Series 60'),
(5, 4, 'Symbian OS 9.4'),
(5, 5, 'классический'),
(5, 1, 'GSM 900/1800/1900, 3G (UMTS)'),
(5, 45, '2010-10-14'),
(6, 10, 'смартфон/коммуникатор'),
(6, 9, 'цветной TFT, 16.78 млн цветов'),
(6, 8, '60x114x10 мм'),
(6, 7, '128 г'),
(6, 6, 'сталь и пластик'),
(6, 3, 'Series 60'),
(6, 4, 'Symbian OS 9.3'),
(6, 5, 'классический'),
(6, 2, 'смартфон/коммуникатор'),
(6, 1, 'GSM 900/1800/1900, 3G (UMTS)'),
(6, 62, 'есть'),
(6, 64, 'есть'),
(6, 65, 'есть'),
(6, 66, 'есть'),
(6, 67, 'есть'),
(6, 68, '1000 номеров'),
(7, 11, '4.2 дюйма'),
(7, 10, 'мультитач, емкостный'),
(7, 9, 'цветной TFT, 16.78 млн цветов, сенсорный'),
(7, 8, '63x125x9 мм'),
(7, 7, '117 г'),
(7, 4, 'Android 2.3'),
(7, 5, 'классический'),
(7, 2, 'смартфон/коммуникатор'),
(7, 1, 'GSM 900/1800/1900, 3G (UMTS)'),
(7, 53, '512 Мб'),
(7, 54, 'Qualcomm MSM 8255, 1000 МГц'),
(7, 55, '31 ч'),
(7, 56, 'голосовой набор, голосовое управление'),
(7, 58, 'фокусировка касанием'),
(7, 60, '512 Мб'),
(7, 61, 'шаблоны сообщений'),
(7, 62, 'есть'),
(9, 10, 'резистивный'),
(9, 8, '52x109x15 мм'),
(9, 9, 'цветной TFT, 16.78 млн цветов, сенсорный'),
(9, 5, 'слайдер'),
(9, 7, '117 г'),
(9, 4, 'Symbian OS 9.4'),
(9, 3, 'Series 60'),
(9, 2, 'смартфон/коммуникатор'),
(9, 1, 'GSM 900/1800/1900, 3G (UMTS)'),
(9, 47, 'лиц, улыбок'),
(9, 48, '1280x720'),
(9, 49, 'есть'),
(9, 51, 'TV-выход'),
(9, 52, 'есть'),
(9, 61, 'шаблоны сообщений'),
(9, 62, 'есть'),
(9, 64, 'есть'),
(11, 14, '64-голосная полифония, MP3-мелодии'),
(11, 12, '240x320 пикс.'),
(11, 6, 'металл и пластик'),
(11, 7, '82 г'),
(11, 8, '47x111x13 мм'),
(11, 9, 'цветной TFT, 262.14 тыс цветов'),
(11, 10, 'телефон'),
(11, 11, '2.2 дюйма'),
(11, 5, 'классический'),
(11, 3, 'Series 40'),
(11, 2, 'телефон'),
(11, 1, 'GSM 900/1800/1900'),
(11, 48, '320x240'),
(11, 52, 'есть'),
(11, 55, '27 ч'),
(11, 56, 'навигационная клавиша'),
(11, 58, 'полный фокус'),
(11, 69, '0.82'),
(14, 8, '59x109x12 мм'),
(14, 9, 'цветной, сенсорный'),
(14, 5, 'классический'),
(14, 7, '120 г'),
(14, 4, 'Android 2.3'),
(14, 2, 'смартфон/коммуникатор'),
(14, 1, 'GSM 900/1800/1900, 3G (UMTS)'),
(14, 53, '512 Мб'),
(14, 54, 'Qualcomm MSM7227, 600 МГц'),
(14, 60, '512 Мб'),
(14, 62, 'есть'),
(14, 70, 'нет'),
(15, 9, 'цветной, сенсорный'),
(15, 8, '62x148x15 мм'),
(15, 7, '161 г'),
(15, 5, 'слайдер'),
(15, 4, 'BlackBerry OS'),
(15, 3, 'BlackBerry OS'),
(15, 2, 'смартфон/коммуникатор'),
(15, 1, 'GSM 900/1800/1900, 3G (UMTS)'),
(15, 52, 'есть'),
(15, 55, '30 ч'),
(15, 58, 'оптический трекпад'),
(15, 60, '512 Мб'),
(15, 62, 'есть'),
(15, 64, 'есть'),
(21, 10, 'резистивный'),
(21, 9, 'цветной, 65.54 тыс цветов, сенсорный'),
(21, 6, 'пластик'),
(21, 7, '118 г'),
(21, 8, '51x103x17 мм'),
(21, 5, 'слайдер'),
(21, 2, 'телефон'),
(21, 1, 'GSM 900/1800/1900'),
(21, 48, '176x144'),
(21, 55, '35 ч'),
(21, 61, 'шаблоны сообщений'),
(21, 72, 'есть'),
(22, 10, 'телефон'),
(22, 9, 'цветной TFT, 262.14 тыс цветов'),
(22, 7, '93 г'),
(22, 8, '61x111x12 мм'),
(22, 5, 'классический'),
(22, 2, 'телефон'),
(22, 1, 'GSM 900/1800/1900'),
(22, 56, 'навигационная клавиша'),
(22, 61, 'шаблоны сообщений'),
(22, 64, 'есть'),
(22, 68, '1000 номеров'),
(26, 10, 'телефон'),
(26, 11, '2.2 дюйма'),
(26, 12, '240x320 пикс.'),
(26, 14, '64-голосная полифония, MP3-мелодии'),
(26, 9, 'цветной, 16.78 млн цветов'),
(26, 5, 'классический'),
(26, 7, '113 г'),
(26, 8, '45x110x11 мм'),
(26, 2, 'телефон'),
(26, 1, 'GSM 900/1800/1900, 3G (UMTS)'),
(26, 61, 'шаблоны сообщений, отправка SMS нескольким адресатам'),
(26, 68, '2000 номеров'),
(27, 9, 'цветной TFT, сенсорный'),
(27, 8, '62x111x14.6 мм'),
(27, 7, '161 г'),
(27, 6, 'пластик'),
(27, 5, 'слайдер'),
(27, 4, 'BlackBerry OS'),
(27, 2, 'смартфон/коммуникатор'),
(27, 3, 'BlackBerry OS'),
(27, 1, 'GSM 900/1800/1900, 3G (UMTS)'),
(27, 58, 'высота смартфона в открытом виде - 147.6 мм; трекпад'),
(27, 60, '768 Мб'),
(27, 62, 'есть'),
(27, 64, 'есть'),
(28, 13, 'есть'),
(28, 14, 'полифонические, MP3-мелодии'),
(28, 10, 'мультитач, емкостный'),
(28, 11, '3.5 дюйма'),
(28, 12, '360x640 пикс.'),
(28, 9, 'цветной IPS, 16.78 млн цветов, сенсорный'),
(28, 8, '56.8x117.2x11 мм'),
(28, 7, '131 г'),
(28, 2, 'смартфон/коммуникатор'),
(28, 3, 'Symbian'),
(28, 5, 'классический'),
(28, 1, 'GSM 900/1800/1900, 3G (UMTS)'),
(28, 69, '0.69'),
(29, 79, '84 дБ'),
(29, 78, 'сеть'),
(29, 7, '8.75 кг'),
(29, 73, 'сухая'),
(29, 74, '1400 Вт'),
(29, 75, 'циклонный фильтр, емкостью 2 л'),
(29, 76, 'на корпусе'),
(29, 77, 'есть'),
(30, 77, 'есть'),
(30, 73, 'сухая'),
(30, 74, '1400 Вт'),
(30, 75, 'циклонный фильтр, емкостью 2 л'),
(30, 76, 'нет'),
(30, 7, '8.78 кг'),
(30, 87, 'есть'),
(31, 75, 'циклонный фильтр, емкостью 2 л'),
(31, 74, '1500 Вт'),
(31, 73, 'сухая'),
(31, 7, '6.75 кг'),
(31, 88, '250 Вт'),
(32, 75, 'циклонный фильтр, емкостью 1.20 л'),
(32, 73, 'сухая'),
(32, 74, '1100 Вт'),
(32, 7, '8.2 кг'),
(32, 88, '200 Вт'),
(32, 89, ' да'),
(33, 73, 'сухая'),
(33, 74, '1400 Вт'),
(33, 75, 'циклонный фильтр, емкостью 2 л'),
(33, 7, '8.66 кг'),
(33, 88, '280 Вт'),
(34, 7, '2.5 кг'),
(34, 6, 'пластик'),
(34, 2, 'стационарный'),
(34, 96, 'есть'),
(34, 97, 'нет'),
(37, 104, 'BSI CMOS'),
(37, 103, '5.62'),
(37, 102, '1/2.3"'),
(37, 101, '16.1 млн'),
(37, 100, '16.79 млн'),
(37, 35, '150 фотографий'),
(37, 32, '71 Мб'),
(37, 25, 'USB 2.0, видео, HDMI, аудио'),
(37, 7, '132 г, с элементами питания'),
(37, 127, '1920x1080'),
(37, 128, '4x'),
(37, 129, 'крепление для штатива'),
(37, 130, '2011-08-24'),
(37, 131, '2011-09-15'),
(37, 132, '99x65x18 мм'),
(38, 101, '10.1 млн'),
(38, 100, '10.34 млн'),
(38, 83, 'диагональ матрицы 1/2,9 дюйма'),
(38, 35, '660 фотографий'),
(38, 25, 'USB 2.0, видео, аудио'),
(38, 7, '170 г, с элементами питания'),
(38, 135, 'есть'),
(38, 136, 'есть'),
(38, 137, 'есть'),
(38, 138, 'есть'),
(39, 105, '80 - 1600 ISO, Auto ISO, ISO6400'),
(39, 104, 'СCD'),
(39, 103, '5.62'),
(39, 102, '1/2.3"'),
(39, 101, '14.1 млн'),
(39, 100, '14.48 млн'),
(39, 35, '330 фотографий'),
(39, 32, '102 Мб'),
(39, 25, 'USB 2.0, видео, HDMI, аудио'),
(39, 7, '431 г, с элементами питания'),
(39, 135, 'есть'),
(39, 136, 'есть'),
(39, 138, 'есть'),
(39, 139, 'NIKKOR'),
(39, 140, '30 кадров/с'),
(39, 141, '30 кадров/с при разрешении 1280x720'),
(39, 142, 'есть'),
(40, 105, '80 - 3200 ISO, Auto ISO'),
(40, 104, 'СCD'),
(40, 103, '5.62'),
(40, 102, '1/2.3"'),
(40, 101, '12 млн'),
(40, 100, '12.39 млн'),
(40, 32, '16 Мб'),
(40, 25, 'USB 2.0, видео, аудио'),
(40, 7, '117 г, с элементами питания'),
(40, 134, 'есть'),
(40, 135, 'есть'),
(40, 136, 'есть'),
(40, 138, 'есть'),
(40, 140, '30 кадров/с'),
(40, 141, '30 кадров/с при разрешении 1280x720'),
(41, 107, 'встроенная, до 4 м, подавление эффекта красных глаз'),
(41, 106, 'автоматический, ручная установка, из списка'),
(41, 104, 'СCD'),
(41, 105, '80 - 1600 ISO, Auto ISO'),
(41, 103, '5.62'),
(41, 102, '1/2.3"'),
(41, 101, '14.1 млн'),
(41, 58, 'асферические линзы'),
(41, 35, '250 фотографий'),
(41, 25, 'USB 2.0, видео, аудио'),
(41, 7, '149 г, с элементами питания'),
(42, 107, 'встроенная, до 3.50 м, подавление эффекта красных глаз'),
(42, 106, 'автоматический, ручная установка, из списка'),
(42, 105, '125 - 3200 ISO, Auto ISO'),
(42, 104, 'CMOS'),
(42, 103, '5.62'),
(42, 100, '10.6 млн'),
(42, 101, '10 млн'),
(42, 102, '1/2.3"'),
(42, 58, 'асферические линзы'),
(42, 25, 'USB 2.0, видео, HDMI, аудио'),
(42, 7, '190 г, без элементов питания'),
(44, 7, '2.3 кг'),
(59, 2, 'ручной'),
(59, 6, 'пластик'),
(59, 7, '1 кг'),
(59, 83, 'HEPA фильтр с антибактериальным экраном Bactisafe задерживает и убивает бактерии и аллергены; радиус действия 10 м; прорезиненные колеса'),
(56, 7, '1 кг'),
(56, 73, 'мокрая курица'),
(56, 74, '1500 Вт'),
(56, 75, 'циклонный фильтр, емкостью 1.20 л'),
(56, 76, 'на корпусе'),
(57, 2, 'ручной'),
(57, 6, 'пластик'),
(57, 7, '2.3 кг'),
(57, 83, 'HEPA фильтр с антибактериальным экраном Bactisafe задерживает и убивает бактерии и аллергены; радиус действия 10 м; прорезиненные колеса'),
(57, 91, '400 Вт'),
(43, 2, 'ручной'),
(43, 6, 'пластик'),
(43, 7, '1 кг'),
(43, 83, 'мягкие колеса; радиус действия 9м; индикатор загрязнения фильтра'),
(44, 73, 'мокрая курица'),
(44, 74, '1500 Вт'),
(44, 75, 'циклонный фильтр, емкостью 1.20 л'),
(56, 1, 'GSM 900/1800/1900, CDMA 800, CDMA 1900, 3G (UMTS), EV-DO Rev. A'),
(56, 2, 'ручной'),
(56, 3, 'Series 60'),
(56, 15, 'есть'),
(56, 16, '5 млн пикс., 2592x1944, светодиодная вспышка'),
(56, 5, 'классический'),
(56, 9, 'цветной, сенсорный'),
(56, 11, '2.36 дюйма'),
(63, 18, '30 кадров/с'),
(62, 1, 'GSM 900/1800/1900, CDMA 800, CDMA 1900, 3G (UMTS), EV-DO Rev. A'),
(62, 2, 'ручной'),
(66, 85, 'есть'),
(66, 86, 'щелевая; для полированных поверхностей; для мягкой мебели; щетка для твердых поверхностей; мини-турбо'),
(1, 73, 'мокрая курица'),
(1, 74, '1500 Вт'),
(1, 76, 'на корпусе'),
(1, 3, 'Series 60'),
(67, 1, 'GSM 900/1800/1900, 3G (UMTS)'),
(1, 19, 'MPEG-4, 3GPP'),
(66, 82, '30.2x49.1x35.2 cм'),
(66, 79, '82 дБ'),
(66, 78, 'сеть'),
(67, 2, 'смартфон/коммуникатор'),
(67, 3, 'Series 60'),
(67, 8, '66.1x125.3x8.49 мм'),
(67, 10, 'мультитач, емкостный'),
(67, 4, 'iOS 5'),
(67, 5, '1500 Вт'),
(72, 7, '1 кг'),
(72, 9, 'цветной, сенсорный'),
(74, 1, 'GSM 900/1800/1900'),
(74, 2, 'стационарный'),
(74, 4, 'iOS 5'),
(75, 7, '1 кг'),
(75, 73, 'сухая'),
(75, 74, '1500 Вт'),
(75, 75, 'циклонный фильтр, емкостью 1.20 л'),
(75, 78, 'сеть'),
(75, 80, '5 м'),
(75, 82, '30.2x39x30 cм'),
(76, 7, '2.3 кг'),
(76, 73, 'сухая'),
(76, 74, '1400 Вт'),
(76, 1, 'GSM 900/1800/1900, CDMA 800, CDMA 1900, 3G (UMTS), EV-DO Rev. A'),
(76, 2, 'стационарный'),
(76, 3, 'Series 40'),
(76, 4, 'iOS 5'),
(76, 5, '1500 Вт'),
(75, 76, 'на корпусе'),
(75, 77, 'есть');

-- --------------------------------------------------------

--
-- Структура таблицы `s_orders`
--

DROP TABLE IF EXISTS `s_orders`;
CREATE TABLE IF NOT EXISTS `s_orders` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `delivery_id` int(11) DEFAULT NULL,
  `delivery_price` float(10,2) NOT NULL DEFAULT '0.00',
  `payment_method_id` int(11) DEFAULT NULL,
  `paid` int(1) NOT NULL DEFAULT '0',
  `payment_date` datetime DEFAULT NULL,
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `phone` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL,
  `comment` varchar(1024) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL,
  `payment_details` text,
  `ip` varchar(15) NOT NULL,
  `total_price` float(10,2) NOT NULL,
  `note` varchar(1024) DEFAULT NULL,
  `discount` float(5,2) NOT NULL DEFAULT '0.00',
  `coupon_discount` float(10,2) NOT NULL DEFAULT '0.00',
  `coupon_code` varchar(255) DEFAULT NULL,
  `separate_delivery` int(1) NOT NULL DEFAULT '0',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `login` (`user_id`),
  KEY `written_off` (`closed`),
  KEY `date` (`date`),
  KEY `status` (`status`),
  KEY `code` (`url`),
  KEY `payment_status` (`paid`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_orders`
--

INSERT INTO `s_orders` (`id`, `delivery_id`, `delivery_price`, `payment_method_id`, `paid`, `payment_date`, `closed`, `date`, `user_id`, `name`, `address`, `phone`, `email`, `comment`, `status`, `url`, `payment_details`, `ip`, `total_price`, `note`, `discount`, `coupon_discount`, `coupon_code`, `separate_delivery`, `modified`) VALUES
(1, 1, 4.00, 0, 0, '2014-10-31 08:03:55', 0, '2012-05-09 15:27:27', 0, 'Артемий Иванов', 'Москва, Шоссе Энтузиастов 56', '545-65-34', 'ai@mail.ru', '', 0, '3bc6d5763e8fd5a3ec784c8561402498', '', '', 35439.00, '', 5.00, 0.00, '', 0, '2013-03-27 08:20:11'),
(2, 0, 0.00, 0, 0, '2014-10-31 08:03:55', 0, '2011-11-09 15:29:04', 0, 'Константин Мельников', 'Москва, ул. Строителей 3', '333-23-23', 'mmk@yandex.ru', '', 0, 'e30a721505aed9c376595d729b1ab3f1', '', '', 19200.00, '', 0.00, 0.00, '', 0, '2013-03-27 08:20:03');

-- --------------------------------------------------------

--
-- Структура таблицы `s_orders_labels`
--

DROP TABLE IF EXISTS `s_orders_labels`;
CREATE TABLE IF NOT EXISTS `s_orders_labels` (
  `order_id` int(11) NOT NULL,
  `label_id` int(11) NOT NULL,
  PRIMARY KEY (`order_id`,`label_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_orders_labels`
--

INSERT INTO `s_orders_labels` (`order_id`, `label_id`) VALUES
(1, 5),
(2, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `s_pages`
--

DROP TABLE IF EXISTS `s_pages`;
CREATE TABLE IF NOT EXISTS `s_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `meta_title` varchar(500) NOT NULL,
  `meta_description` varchar(500) NOT NULL,
  `meta_keywords` varchar(500) NOT NULL,
  `body` longtext NOT NULL,
  `menu_id` int(11) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  `header` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_num` (`position`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_pages`
--

INSERT INTO `s_pages` (`id`, `url`, `name`, `meta_title`, `meta_description`, `meta_keywords`, `body`, `menu_id`, `position`, `visible`, `header`) VALUES
(1, '', 'Главная', 'Хиты продаж', 'Этот магазин является демонстрацией скрипта интернет-магазина  Simpla . Все материалы на этом сайте присутствуют исключительно в демострационных целях.', 'Хиты продаж', '<p>Этот магазин является демонстрацией скрипта интернет-магазина <a href="http://simplacms.ru">Simpla</a>. Все материалы на этом сайте присутствуют исключительно в демострационных целях.</p>', 1, 1, 1, 'О магазине'),
(2, 'oplata', 'Оплата', 'Оплата', 'Оплата', 'Оплата', '<h2><span>Наличными курьеру</span></h2><p>Вы можете оплатить заказ курьеру в гривнах непосредственно в момент доставки. Курьерская доставка осуществляется по Москве на следующий день после принятия заказа.</p><h2>Webmoney</h2><p>После оформления заказа вы сможете перейти на сайт webmoney для оплаты заказа, где сможете оплатить заказ в автоматическом режиме, а так же проверить наш сертификат продавца.</p><h2>Наличными в офисе Автолюкса</h2><p>При доставке заказа системой Автолюкс, вы сможете оплатить заказ в их офисе непосредственно в момент получения товаров.</p>', 1, 4, 1, 'Способы оплаты'),
(3, 'dostavka', 'Доставка', 'Доставка', 'Доставка', 'Доставка', '<h2>Курьерская доставка по&nbsp;Москве</h2><p>Курьерская доставка осуществляется на следующий день после оформления заказа<span style="margin-right: -0.2em;">,</span><span style="margin-left: 0.2em;"> </span>если товар есть в&nbsp;наличии. Курьерская доставка осуществляется в&nbsp;пределах Томска и&nbsp;Северска ежедневно с&nbsp;10.00 до&nbsp;21.00. Заказ на&nbsp;сумму свыше 300 рублей доставляется бесплатно. <br /><br />Стоимость бесплатной доставки раcсчитывается от&nbsp;суммы заказа с&nbsp;учтенной скидкой. В&nbsp;случае если сумма заказа после применения скидки менее 300р<span style="margin-right: -0.2em;">,</span><span style="margin-left: 0.2em;"> </span>осуществляется платная доставка. <br /><br />При сумме заказа менее 300 рублей стоимость доставки составляет от 50 рублей.</p><h2>Самовывоз</h2><p>Удобный<span style="margin-right: -0.2em;">,</span><span style="margin-left: 0.2em;"> </span>бесплатный и быстрый способ получения заказа.<br />Адрес офиса: Москва<span style="margin-right: -0.2em;">,</span><span style="margin-left: 0.2em;"> </span>ул. Арбат<span style="margin-right: -0.2em;">,</span><span style="margin-left: 0.2em;"> </span>1/3<span style="margin-right: -0.2em;">,</span><span style="margin-left: 0.2em;"> </span>офис 419.</p><h2>Доставка с&nbsp;помощью предприятия<span style="margin-right: 0.44em;"> </span><span style="margin-left: -0.44em;">&laquo;</span>Автотрейдинг&raquo;</h2><p>Удобный и быстрый способ доставки в крупные города России. Посылка доставляется в офис<span style="margin-right: 0.44em;"> </span><span style="margin-left: -0.44em;">&laquo;</span>Автотрейдинг&raquo; в&nbsp;Вашем городе. Для получения необходимо предъявить паспорт и&nbsp;номер грузовой декларации<span style="margin-right: 0.3em;"> </span><span style="margin-left: -0.3em;">(</span>сообщит наш менеджер после отправки). Посылку желательно получить в&nbsp;течение 24 часов с&nbsp;момента прихода груза<span style="margin-right: -0.2em;">,</span><span style="margin-left: 0.2em;"> </span>иначе компания<span style="margin-right: 0.44em;"> </span><span style="margin-left: -0.44em;">&laquo;</span>Автотрейдинг&raquo; может взыскать с Вас дополнительную оплату за хранение. Срок доставки и стоимость Вы можете рассчитать на сайте компании.</p><h2>Наложенным платежом</h2><p>При доставке заказа наложенным платежом с помощью<span style="margin-right: 0.44em;"> </span><span style="margin-left: -0.44em;">&laquo;</span>Почты России&raquo;, вы&nbsp;сможете оплатить заказ непосредственно в&nbsp;момент получения товаров.</p>', 1, 3, 1, 'Способы доставки'),
(4, 'blog', 'Блог', 'Блог', '', 'Блог', '', 1, 2, 1, 'Блог'),
(5, '404', '', 'Страница не найдена', 'Страница не найдена', 'Страница не найдена', '<p>Страница не найдена</p>', 2, 5, 1, 'Страница не найдена'),
(6, 'contact', 'Контакты', 'Контакты', 'Контакты', 'Контакты', '<p>Москва, шоссе Энтузиастов 45/31, офис 453.</p><p><a href="http://maps.yandex.ru/?text=%D0%A0%D0%BE%D1%81%D1%81%D0%B8%D1%8F%2C%20%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0%2C%20%D0%AD%D0%BD%D1%82%D1%83%D0%B7%D0%B8%D0%B0%D1%81%D1%82%D0%BE%D0%B2%20%D1%88%D0%BE%D1%81%D1%81%D0%B5%2C%2051&amp;sll=37.823314%2C55.773034&amp;sspn=0.021955%2C0.009277&amp;ll=37.826161%2C55.77356&amp;spn=0.019637%2C0.006461&amp;l=map">Посмотреть на&nbsp;Яндекс.Картах</a></p><p>Телефон 345-45-54</p>', 1, 6, 1, 'Котакты'),
(7, 'products', 'Все товары', 'Все товары', '', 'Все товары', '', 2, 7, 1, 'Все товары');

-- --------------------------------------------------------

--
-- Структура таблицы `s_payment_methods`
--

DROP TABLE IF EXISTS `s_payment_methods`;
CREATE TABLE IF NOT EXISTS `s_payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `currency_id` float NOT NULL,
  `settings` text NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `position` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_payment_methods`
--

INSERT INTO `s_payment_methods` (`id`, `module`, `name`, `description`, `currency_id`, `settings`, `enabled`, `position`) VALUES
(1, 'Receipt', 'Квитанция', '<p>Вы можете распечатать квитанцию и оплатить её в любом отделении банка.</p>', 2, 'a:10:{s:9:"recipient";s:65:"ООО "Великолепный интернет-магазин"";s:3:"inn";s:5:"12345";s:7:"account";s:6:"223456";s:4:"bank";s:18:"Альфабанк";s:3:"bik";s:6:"556677";s:21:"correspondent_account";s:11:"77777755555";s:8:"banknote";s:7:"руб.";s:5:"pense";s:7:"коп.";s:5:"purse";s:2:"ru";s:10:"secret_key";s:0:"";}', 1, 2),
(2, 'Webmoney', 'Webmoney wmz', '<p><span></span></p><div><p>Оплата через платежную систему&nbsp;<a href="http://www.webmoney.ru">WebMoney</a>. У вас должен быть счет в этой системе для того, чтобы произвести оплату. Сразу после оформления заказа вы будете перенаправлены на специальную страницу системы WebMoney, где сможете произвести платеж в титульных знаках WMZ.</p></div><p>&nbsp;</p>', 3, 'a:10:{s:9:"recipient";s:0:"";s:3:"inn";s:0:"";s:7:"account";s:0:"";s:4:"bank";s:0:"";s:3:"bik";s:0:"";s:21:"correspondent_account";s:0:"";s:8:"banknote";s:7:"руб.";s:5:"pense";s:0:"";s:5:"purse";s:13:"Z111111111111";s:10:"secret_key";s:13:"testsecretkey";}', 1, 1),
(3, 'Robokassa', 'Робокасса', '<p><span>RBK Money &ndash; это электронная платежная система, с помощью которой Вы сможете совершать платежи с персонального компьютера, коммуникатора или мобильного телефона.</span></p>', 3, 'a:14:{s:9:"recipient";s:0:"";s:3:"inn";s:0:"";s:7:"account";s:0:"";s:4:"bank";s:0:"";s:3:"bik";s:0:"";s:21:"correspondent_account";s:0:"";s:8:"banknote";s:0:"";s:5:"pense";s:0:"";s:5:"login";s:0:"";s:9:"password1";s:0:"";s:9:"password2";s:0:"";s:8:"language";s:2:"ru";s:5:"purse";s:0:"";s:10:"secret_key";s:0:"";}', 1, 3),
(4, 'Paypal', 'PayPal', '<p>Совершайте покупки безопасно, без раскрытия информации о своей кредитной карте. PayPal защитит вас, если возникнут проблемы с покупкой</p>', 1, 'a:16:{s:8:"business";s:0:"";s:4:"mode";s:7:"sandbox";s:9:"recipient";s:0:"";s:3:"inn";s:0:"";s:7:"account";s:0:"";s:4:"bank";s:0:"";s:3:"bik";s:0:"";s:21:"correspondent_account";s:0:"";s:8:"banknote";s:0:"";s:5:"pense";s:0:"";s:5:"login";s:0:"";s:9:"password1";s:0:"";s:9:"password2";s:0:"";s:8:"language";s:2:"ru";s:5:"purse";s:0:"";s:10:"secret_key";s:0:"";}', 1, 4),
(5, 'Interkassa', 'Оплата через Интеркассу', '<p><span>Это удобный в использовании сервис, подключение к которому позволит Интернет-магазинам, веб-сайтам и прочим торговым площадкам принимать все возможные формы оплаты в максимально короткие сроки.</span></p>', 2, 'a:2:{s:18:"interkassa_shop_id";s:3:"123";s:21:"interkassa_secret_key";s:3:"123";}', 1, 5),
(6, 'Liqpay', 'Оплата картой через Liqpay.com', '<p><span>Благодаря своей открытости и универсальности LiqPAY стремительно интегрируется со многими платежными системами и платформами и становится стандартом платежных операций.</span></p>', 2, 'a:5:{s:9:"liqpay_id";s:3:"123";s:11:"liqpay_sign";s:3:"123";s:12:"pay_way_card";s:1:"1";s:14:"pay_way_liqpay";s:1:"1";s:15:"pay_way_delayed";s:1:"1";}', 1, 6),
(7, 'Pay2Pay', 'Оплата через Pay2Pay', '<p>Универсальный платежный сервис Pay2Pay призван облегчить и максимально упростить процесс приема электронных платежей на Вашем сайте. Мы открыты для всего нового и сверхсовременного.</p>', 2, 'a:5:{s:18:"pay2pay_merchantid";s:3:"123";s:14:"pay2pay_secret";s:3:"123";s:14:"pay2pay_hidden";s:3:"123";s:15:"pay2pay_paymode";s:3:"123";s:16:"pay2pay_testmode";s:1:"1";}', 1, 7),
(8, 'Qiwi', 'Оплатить через QIWI', '<p><span>QIWI &mdash; удобный сервис для оплаты повседневных услуг</span></p>', 2, 'a:2:{s:10:"qiwi_login";s:3:"123";s:13:"qiwi_password";s:3:"123";}', 1, 8);

-- --------------------------------------------------------

--
-- Структура таблицы `s_products`
--

DROP TABLE IF EXISTS `s_products`;
CREATE TABLE IF NOT EXISTS `s_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL DEFAULT '',
  `brand_id` int(11) DEFAULT NULL,
  `name` varchar(500) NOT NULL,
  `annotation` text NOT NULL,
  `body` longtext NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `position` int(11) NOT NULL DEFAULT '0',
  `meta_title` varchar(500) NOT NULL,
  `meta_keywords` varchar(500) NOT NULL,
  `meta_description` varchar(500) NOT NULL,
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `featured` tinyint(1) DEFAULT NULL,
  `external_id` varchar(36) NOT NULL,
  `update` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `url` (`url`),
  KEY `brand_id` (`brand_id`),
  KEY `visible` (`visible`),
  KEY `position` (`position`),
  KEY `external_id` (`external_id`),
  KEY `hit` (`featured`),
  KEY `name` (`name`(333))
) ENGINE=MyISAM AUTO_INCREMENT=96 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_products`
--

INSERT INTO `s_products` (`id`, `url`, `brand_id`, `name`, `annotation`, `body`, `visible`, `position`, `meta_title`, `meta_keywords`, `meta_description`, `created`, `featured`, `external_id`, `update`) VALUES
(1, 'apple-iphone-4s-16gb', 1, 'Apple iPhone 4S 16Gb', '<p>iPhone 4 стал настоящим хитом продаж по всему миру, но компания Apple не стоит на месте, усовершенствованная модель iPhone 4s обзавелась новым процессором, 8ми мегапиксельной камерой и голосовым помошником Siri. Многие оценят тот факт, что наряду с моделями оснащенными 16Gb и 32Gb памяти теперб можно купить айфон с 64Gb памяти.fdsadsf</p>\r\n', '<p>iPhone 4 получил 3,5-дюймовый дисплей с разрешением 960 x 640 пикселей. Толщина устройства всего 9,3 мм. Передняя и задняя стороны аппарата обе плоские, выполнены из стекла, торцевая окантовка - стальная. У телефона есть фронтальная камера для видеозвонков, дополнительный микрофон для шумоподавления, а слот SIM сменился на Micro SIM. Батарея обеспечивает до 14 часов в режиме разговора, 6/10 часов в режиме веб-серфинга по 3G/Wi-Fi, 10 часов просмотра видео, 40 часов прослушивания музыки и 300 часов режима ожидания. Кроме того, добавлена поддержка Wi-Fi 802.11n. Разрешение основной камеры 5 МП, имеется поддержка видеосъемки с разрешением 1280 x 720 пикселей со скоростью 30 кадров в секунду.Дисплей 3,5 дюйма, 640х960 точек, IPS, олеофобное покрытие / Двухъядерный A5 Чип, Графический ускоритель PowerVR SGX543MP2 / 8-мегапиксельная фотокамера, HD видео (1080pх) / Bluetooth 4.0 и Wi-Fi 802.11b/g/n / гарантия - 12 месяцев.dasfdasfadsf</p>\r\n', 1, 1, 'Apple iPhone 4S 16Gb', 'Apple iPhone 4S 16Gb, Apple, Мобильные телефоны', 'iPhone 4 стал настоящим хитом продаж по всему миру, но компания Apple не стоит на месте, усовершенствованная модель iPhone 4s обзавелась новым процессором, 8ми мегапиксельной камерой и голосовым помошником Siri. Многие оценят тот факт, что наряду с моделями оснащенными 16Gb и 32Gb памяти теперб можно купить айфон с 64Gb памяти.', '2011-10-18 16:11:27', 1, '0', NULL),
(2, 'samsung-galaxy-s-ii', 2, 'Samsung Galaxy S II', '<p>Samsung Galaxy S II &ndash; смартфон под управлением ОС Android 2.3. Samsung Galaxy S II оснащен 4.3 дюймовым Super AMOLED Plus дисплеем, двухъядерным процессором с тактовой частотой 1 ГГц, 8-ми мегапиксельной камерой с автофокусом и светодиодной вспышкой, 1 Гб оперативной памяти, встроенной памятью объемом 8 или 16 Гб (в зависимости от конфигурации), аккумулятором емкостью 1650 мАч.</p>', '<p><span>Стильный смартфон&nbsp;</span><strong>Samsung I9100 Galaxy S II&nbsp; 16Gb</strong><span>&nbsp;&ndash; это огромный и необыкновенно яркий экран, тончайший корпус, покоряющий своей невесомостью, высочайшая скорость работы всех приложений и, конечно, очень удобная операционная система "Андроид"! А какая в этом смартфоне установлена камера! Лучшая в своем классе, 8-мегапиксельная да еще и с автофокусом и системой распознавания лиц, улыбок. Электронный стабилизатор, кстати говоря, тоже присутствует, как и функция геометок. В условиях недостаточной освещенности выручает дальнобойная светодиодная вспышка. И это далеко не полный перечень преимуществ данной модели! Большой объем встроенной памяти и наличие слота для microSD-карт порадуют всех любителей новомодных приложений. В телефоне Samsung I9100 Galaxy S II поместится буквально все: фильмы, музыка, фотографии, интерактивные видеообои &ndash; в общем, что душе угодно! Добавим к этому увеличенную, по сравнению с предыдущей моделью, емкость аккумулятора (1650 мАч) и получаем практически идеальный во всех отношениях смартфон!</span>\r\n</p>', 1, 38, 'Samsung Galaxy S II', 'Samsung Galaxy S II, Samsung, Мобильные телефоны ', 'Samsung Galaxy S II &ndash; смартфон под управлением ОС Android 2.3. Samsung Galaxy S II оснащен 4.3 дюймовым Super AMOLED Plus дисплеем, двухъядерным процессором с тактовой частотой 1 ГГц, 8-ми мегапиксельной камерой с автофокусом и светодиодной вспышкой, 1 Гб оперативной памяти, встроенной памятью объемом 8 или 16 Гб (в зависимости от конфигурации), аккумулятором емкостью 1650 мАч.', '2011-10-18 16:18:52', 0, '', NULL),
(3, 'htc-incredible-s', 4, 'HTC Incredible S', '<p>HTC Incredible S &ndash; смартфон под управлением ОС Android 2.2. HTC Incredible S оснащен 4-х дюймовым сенсорным мультитач дисплеем с разрешением 480 x 800 пикселей, процессором с тактовой частотой 1 ГГц, 8 мегапиксельной камерой с автофокусом и двойной светодиодной вспышкой, 1.3 мегапиксельной фронтальной камерой, оперативной памятью объемом 768 Мбайт.</p>', '<p>HTC Incredible S оснащен дисплеем диагональю 4 дюймов (Super LCD, 800 x 480 пикселей), чипом Qualcomm с частотой 1 ГГц, ОЗУ 768 МБ, 8-МП камерой с автофокусом, двойной светодиодной вспышкой и возможностью видеосъемки в формате 720p, а также фронтальной камерой на 1,3 МП для видео звонков.</p>', 1, 37, 'HTC Incredible S', 'HTC Incredible S, HTC, Мобильные телефоны', 'HTC Incredible S &ndash; смартфон под управлением ОС Android 2.2. HTC Incredible S оснащен 4-х дюймовым сенсорным мультитач дисплеем с разрешением 480 x 800 пикселей, процессором с тактовой частотой 1 ГГц, 8 мегапиксельной камерой с автофокусом и двойной светодиодной вспышкой, 1.3 мегапиксельной фронтальной камерой, оперативной памятью объемом 768 Мбайт.', '2011-10-18 16:21:42', 1, '', NULL),
(4, 'htc-sensation', 4, 'HTC Sensation', '<p>Превосходное воспроизведение фильмов на великолепном qHD дисплее с кристально чистым Hi-Fi звуком. HTC Sensation оснащен обновленным интерфейсом HTC Sense, который, впечатляет реалистичностью и превращает телефон в очень удобный, да и просто лучший, инструмент для развлечений. Премиальный дизайн, плавно изогнутый контур упрочненного стекла &ndash; этот телефон отлично ляжет в твою руку. HTC Sensation &ndash; это настоящий мультимедийный суперфон.</p>', '<p><span>HTC Sensation оснащен дисплеем диагональю 4.3 дюймов (Super LCD, 960 x 540 пикселей), чипом Qualcomm с частотой 1.2 ГГц, ОЗУ 768 МБ, 8-МП камерой с автофокусом, двойной светодиодной вспышкой и возможностью видеосъемки в формате 1080p, а также фронтальной камерой на 0.3 МП для видео звонков.</span></p>', 1, 41, 'HTC Sensation', 'HTC Sensation, HTC, Мобильные телефоны', 'Превосходное воспроизведение фильмов на великолепном qHD дисплее с кристально чистым Hi-Fi звуком. HTC Sensation оснащен обновленным интерфейсом HTC Sense, который, впечатляет реалистичностью и превращает телефон в очень удобный, да и просто лучший, инструмент для развлечений. Премиальный дизайн, плавно изогнутый контур упрочненного стекла &ndash; этот телефон отлично ляжет в твою руку. HTC Sensation &ndash; это настоящий мультимедийный суперфон.', '2011-10-18 16:23:10', 1, '', NULL),
(5, 'nokia-c5-03', 3, 'Nokia C5-03', '<p>Nokia C5-03 - отличный смартфон, работающий на платформе S60 5th Edition с процессором ARM 11 600Mhz, оснащенный TFT-дисплеем, отображающим до 16 млн. цветов, с диагональю 3.2" и камерой на 5 Mpx, делающей снимки с разрешением 2592 x 1944 px. C5-03 оснащен мощным аккумулятором на 1000 mAh, который позволяет аппарату работать до 600 часов в режиме ожидания и до 11.5 в режиме разговора.</p>', '<p>Nokia C5-03 комплектуется отличным сенсорным экраном, ориентированным для управления пальцами. Дисплей представляет собой TFT-матрицу диагональю 3.2 дюйма с разрешением 360х640 пикселей и способностью отображать до 16 млн. цветов. Зернистость - минимальна, цветопередача - на очень высоком уровне - все краски насыщенные, живые. Яркость экрана можно регулировать самостоятельно, а можно положиться на датчик освещенности, который своей работой экономит заряд батареи. Резистивная технология позволяет управлять устройством не только пальцами, но и стилусом или любым другим предметом. Кстати, зимой можно не снимать перчаток.</p>', 1, 36, 'Nokia C5-03', 'Nokia C5-03, Nokia, Мобильные телефоны', 'Nokia C5-03 - отличный смартфон, работающий на платформе S60 5th Edition с процессором ARM 11 600Mhz, оснащенный TFT-дисплеем, отображающим до 16 млн. цветов, с диагональю 3.2" и камерой на 5 Mpx, делающей снимки с разрешением 2592 x 1944 px. C5-03 оснащен мощным аккумулятором на 1000 mAh, который позволяет аппарату работать до 600 часов в режиме ожидания и до 11.5 в режиме разговора.', '2011-10-18 16:29:06', 0, '', NULL),
(6, 'nokia-e72', 3, 'Nokia E72', '<p>Nokia E72 пришел на смену модели Nokia E71, у которой камера была 3-Мп, а у новинки Nokia E72 &mdash; камера 5-Мп. Nokia E72 выполнен в форм-факторе моноблока с QWERTY-клавиатурой. Толщина корпуса составляет всего 10 миллиметров.</p>', '<p>Nokia E72 - отличный смартфон, работающий на платформе S60 3rd Edition, Feature Pack 2 с процессором ARM 11 600Mhz, оснащенный TFT-дисплеем, отображающим до 16 млн. цветов, с диагональю 2.36" и камерой на 5 Mpx, делающей снимки с разрешением 2592 x 1944 px. Оснащен очень мощным аккумулятором на 1500 mAh, который позволяет аппарату работать до 384 часов в режиме ожидания и до 13 в режиме разговора. Для коммуникации может предложить: Web-браузер, EDGE, WiFi, стерео Bluetooth, и, конечно, USB-порт. Для любителей музыки есть аудио выход на 3.5 мм. Также стоит отметить, что он оснащен GPS-приемником, который позволит Вам не заблудиться в любом месте!</p>', 1, 35, 'Nokia E72', 'Nokia E72, Nokia, Мобильные телефоны', 'Nokia E72 пришел на смену модели Nokia E71, у которой камера была 3-Мп, а у новинки Nokia E72 &mdash; камера 5-Мп. Nokia E72 выполнен в форм-факторе моноблока с QWERTY-клавиатурой. Толщина корпуса составляет всего 10 миллиметров.', '2011-10-18 16:32:05', 0, '', NULL),
(7, 'sony-ericsson-xperia-arc', 5, 'Sony Ericsson Xperia arc', '<p>Смартфон Sony Ericsson Xperia Arc заставит тебя забыть все телефоны, которые у тебя были до него. Ты не сможешь даже подумать о том, что раньше мог пользоваться чем-то другим. Ведь этот гаджет отличается стильным дизайном и непревзойденной функциональностью. Быстроту работы всех приложений в режиме многозадачности обеспечат новейшая операционная система Android v2.3 и оперативная память объемом 512 Мб, а удобство управления телефоном и высококачественную, яркую картинку &ndash; сенсорный емкостной 4,2-дюймовый экран Reality Display с разрешением 854x480 точек и поддержкой технологии "мультитач".</p>', '<p>Sony Ericsson Xperia Arc - замечательный смартфон, работающий на платформе Android с процессором Qualcomm QSD8250 1000Mhz, оснащенный TFT-дисплеем, отображающим до 16 млн. цветов, с диагональю 4.2" и камерой на 8.1 Mpx, делающей снимки с разрешением 3264 x 2448 px. Sony Ericsson Xperia Arc оснащен очень мощным аккумулятором на 1500 mAh, который позволяет аппарату работать до 400 часов в режиме ожидания и до 7 в режиме разговора. Для коммуникации Sony Ericsson Xperia Arc может предложить: WAP браузер, EDGE, WiFi, стерео Bluetooth, ну и, конечно, USB-порт. Для любителей музыки есть аудио выход на 3.5 мм. Также стоит отметить, что Sony Ericsson Xperia Arc оснащен GPS-приемником, который позволит Вам не заблудиться в любом месте!</p>', 1, 34, 'Sony Ericsson Xperia arc', 'Sony Ericsson Xperia arc, Sony Ericsson, Мобильные телефоны', 'Смартфон Sony Ericsson Xperia Arc заставит тебя забыть все телефоны, которые у тебя были до него. Ты не сможешь даже подумать о том, что раньше мог пользоваться чем-то другим. Ведь этот гаджет отличается стильным дизайном и непревзойденной функциональностью. Быстроту работы всех приложений в режиме многозадачности обеспечат новейшая операционная система Android v2.3 и оперативная память объемом 512 Мб, а удобство управления телефоном и высококачественную, яркую картинку &ndash; сенсорный емкостн', '2011-10-18 16:40:28', 0, '', NULL),
(8, 'samsung-s5570-galaxy-mini', 2, 'Samsung S5570 Galaxy Mini', '<p>GALAXY mini &mdash; это внушительный спектр функциональных возможностей в эргономичном корпусе с запоминающимся дизайном. Приобретая GALAXY mini, Вы открываете для себя удивительную вселенную смартфонов. Не доверяете всеобщему восторгу? Проверьте сами!</p>', '<p>Samsung Galaxy Mini GT-S5570 - выполнен в форм-факторе моноблок. Имеет 3.14 дюймовый дисплей с разрешением 240 на 320 пикселей, 3.2 МП камеру, 3.5 мм разъём для подключения гарнитуры, поддержку карт памяти microSD, FM-радио, Bluetooth, Wi-Fi и GPS модули.</p>', 1, 42, 'Samsung S5570 Galaxy Mini', 'Samsung S5570 Galaxy Mini, Samsung, Мобильные телефоны', 'GALAXY mini &mdash; это внушительный спектр функциональных возможностей в эргономичном корпусе с запоминающимся дизайном. Приобретая GALAXY mini, Вы открываете для себя удивительную вселенную смартфонов. Не доверяете всеобщему восторгу? Проверьте сами!', '2011-10-18 16:43:57', 1, '', NULL),
(9, 'sony-ericsson-vivaz', 5, 'Sony Ericsson Vivaz', '<p>Sony Ericsson Vivaz выполнен в форм-факторе моноблок. Имеет 3.2 дюймовый дисплей с разрешением 360 на 640 пикслей, 8 МП камера с автофокусом и вспышкой, 3.5 мм разъём для подключения гарнитуры, поддержка карт памяти MicroSD, FM-радио, Bluetooth, Wi-Fi и GPS модули.</p>', '<p>Остановите мгновение с помощью Sony Ericsson Vivaz. Жизнь вашими глазами. На видео HD-качества с телефоном Sony Ericsson Vivaz. Раз уж вы здесь, почему бы не заснять все это на видео и не показать всему миру? Ощутите себя настоящим кинорежиссером. Для этого достаточно просто включить камеру. Одно нажатие на кнопку камеры - и вы готовы к съемке. Всегда в фокусе. Волейбол на пляже, фрисби в парке. Непрерывная автоматическая фокусировка позволяет снимать все происходящее с высокой четкостью. Покажите всему миру, какой вы кинооператор! Загрузите свои шедевры на YouTube или Picasa через Wi-Fi.</p><p>Интуитивный интерфейс упрощает работу с телефоном, будь то поиск медиаданных, настройка параметров камеры или воспроизведение музыки. Просмотр изображения возможен в альбомной и книжной ориентации. Для переключения режима достаточно повернуть телефон.</p><p>Найдите свой путь с помощью aGPS. Вы больше никогда не заблудитесь. Ваш телефон оснащен встроенной системой aGPS. Службы определения местонахождения помогут вам узнать дорогу к месту назначения. Функция геотегирования позволяет добавлять географическую информацию к вашим изображениям.</p><p>Теперь развлечения будут всегда с вами - Media Go позволяет без труда систематизировать содержимое вашего телефона и добавлять новый контент. Переносите медиафайлы с телефона на компьютер и наоборот простым перетаскиванием. Кроме того, Media Go автоматически преобразует фильмы и аудиофайлы в необходимый формат для обеспечения наилучшего качества.</p><p>&nbsp;</p>', 1, 33, 'Sony Ericsson Vivaz', 'Sony Ericsson Vivaz, Sony Ericsson, Мобильные телефоны', 'Sony Ericsson Vivaz выполнен в форм-факторе моноблок. Имеет 3.2 дюймовый дисплей с разрешением 360 на 640 пикслей, 8 МП камера с автофокусом и вспышкой, 3.5 мм разъём для подключения гарнитуры, поддержка карт памяти MicroSD, FM-радио, Bluetooth, Wi-Fi и GPS модули.', '2011-10-18 16:47:13', 0, '', NULL),
(10, 'nokia-x3-02', 3, 'Nokia X3-02', '<p>Новая Nokia X3-02 с 5 Мпикс камерой, стильным тонким дизайном и поддержкой современных социальных сетей идеально подойдёт всем, кто хочет всегда оставаться на связи.</p>', '<p>Nokia X3-02 - замечательный телефон, работающий на платформе Series 40 6th Edition, Feature Pack 1, оснащенный TFT-дисплеем, отображающим до 262 тыс. цветов, с диагональю 2.4" и камерой на 5 Mpx, делающей снимки с разрешением 2592 x 1944 px. Оснащен аккумулятором на 860 mAh, который позволяет аппарату работать до 430 часов в режиме ожидания и до 5.3 в режиме разговора. Для коммуникации может предложить: Web-браузер, EDGE, WiFi, стерео Bluetooth, и, конечно, USB-порт. Для любителей музыки есть аудио выход на 3.5 мм.</p>', 1, 32, 'Nokia X3-02', 'Nokia X3-02, Nokia, Мобильные телефоны', 'Новая Nokia X3-02 с 5 Мпикс камерой, стильным тонким дизайном и поддержкой современных социальных сетей идеально подойдёт всем, кто хочет всегда оставаться на связи.', '2011-10-18 16:50:13', 0, '', NULL),
(11, 'nokia-x2-00', 3, 'Nokia X2-00', '<p><span>Мобильный телефон в стиле ретро, который отлично подходит для прослушивания музыки, фотосъемки и обмена данными. Дизайн позаимствован с когда-то популярного телефона SonyEricsson T100.</span></p>', '<p>Оригинальный корпус nokia x2 с изогнутой задней панелью, мощные стереодинамики для отличного звука, В nokia x2 00 есть FM-радио, а также камера 5 мегапикселей со светодиодной вспышкой и 4-кратным цифровым увеличением для прекрасных снимков. Телефон x2, который обладает идеальным функционалом и доступной ценой.</p>', 1, 31, 'Nokia X2-00', 'Nokia X2-00, Nokia, Мобильные телефоны', 'Мобильный телефон в стиле ретро, который отлично подходит для прослушивания музыки, фотосъемки и обмена данными. Дизайн позаимствован с когда-то популярного телефона SonyEricsson T100.', '2011-10-18 16:56:11', 0, '', NULL),
(12, 'nokia-e7', 3, 'Nokia E7', '<p>Nokia E7 &ndash; боковой слайдер под управлением операционной системы Symbian^3. Nokia E7 оснащен 4-х дюймовым CBD (ClearBlack Display) дисплеем с разрешением 360 x 640 пикселей, 8-ми мегапиксельной камерой с двойной светодиодной вспышкой и полноценной QWERTY-клавиатурой.</p>', '<p>Nokia E7 - идеальный бизнес-смартфон. Устройство имеет встроенную почтовую службу Microsoft Exchange ActiveSync, обеспечивающую прямой и безопасной доступ к корпоративной электронной почте в режиме реального времени, а также включает комплекс решений для обеспечения безопасности на корпоративном уровне. Модель имеет 4-дюймовый сенсорный дисплей с технологией Nokia ClearBlack с улучшенной видимостью на улице и полноценную клавиатуру, что делает Nokia E7 идеальным инструментом для работы с документами, электронными таблицами, а также просмотра и редактирования слайдов презентаций.</p>', 1, 30, 'Nokia E7', 'Nokia E7, Nokia, Мобильные телефоны', 'Nokia E7 &ndash; боковой слайдер под управлением операционной системы Symbian^3. Nokia E7 оснащен 4-х дюймовым CBD (ClearBlack Display) дисплеем с разрешением 360 x 640 пикселей, 8-ми мегапиксельной камерой с двойной светодиодной вспышкой и полноценной QWERTY-клавиатурой.', '2011-10-18 16:57:48', 0, '', NULL),
(13, 'nokia-c6-00', 3, 'Nokia C6-00', '<p>Телефон Nokia C6-00 с полноценной QWERTY-клавиатурой создан для молодежи, которая активно общается. Данное устройство является облегченным аналогом более старшей модели Nokia X6, имеет тот же порядковый номер, но с добавлением режима виджетов.</p>', '<p>С Nokia C6-00 общение станет еще более простым и удобным, благодаря быстрому доступу к электронной почте, контактам и социальным сетям. Притом, с помощью QWERTY-клавиатуры вы сможете писать сообщения в привычном темпе, не теряя времени на обдумывание, какую клавишу нужно нажать. Кстати, с помощью виджетов можно настроить рабочий стол так, чтобы в режиме реально времени загружались обновления из Facebook и других социальных сетей, также можно добавить ярлыки для быстрого доступа к контактам, чтобы быть ближе к друзьям. Когда решите пообщаться с приятелями лично, то спокойно отправляйтесь туда, куда они позовут, не боясь заблудиться, ведь в вашем смартфоне есть приемник GPS.</p>', 1, 29, 'Nokia C6-00', 'Nokia C6-00, Nokia, Мобильные телефоны', 'Телефон Nokia C6-00 с полноценной QWERTY-клавиатурой создан для молодежи, которая активно общается. Данное устройство является облегченным аналогом более старшей модели Nokia X6, имеет тот же порядковый номер, но с добавлением режима виджетов.', '2011-10-18 17:01:43', 0, '', NULL),
(14, 'htc-salsa', 4, 'HTC Salsa', '<p>HTC Salsa - новый смартфон компании HTC под управлением операционной системы Google Android 2.4. HTC Salsa имеет 3,4-дюймовый WVGA экран с разрешением 480&times;320 пикселей. Габариты устройства составляют 109,1&times;58,9&times;12,3 мм. Смартфон весит 120 граммов. HTC Salsa оснащен 5-ти мегапиксельной камерой с автофокусом и светодиодной вспышкой.</p>', '<p>HTC Salsa - новый смартфон компании HTC под управлением операционной системы Google Android 2.4. HTC Salsa имеет 3,4-дюймовый WVGA экран с разрешением 480&times;320 пикселей. Габариты устройства составляют 109,1&times;58,9&times;12,3 мм. Смартфон весит 120 граммов. HTC Salsa оснащен 5-ти мегапиксельной камерой с автофокусом и светодиодной вспышкой. Для подключения проводной гарнитуры и наушников имеется стандартный 3.5 мм аудиовыход. Аккумулятор имеет емкость 1520 мАч. HTC Salsa обладает неплохой производительностью благодаря наличию процессора 600 МГц и оперативной памяти 512 Мб. Объем встроенной памяти смартфона составляет 512 Мб, которая может быть расширена посредством карт памяти microSD.</p><p>Отличительной особенностью HTC Salsa является плотная интеграция с Facebook (это второй подобный смартфон компании HTC). Для доступа к сервисам самой популярной в мире социальной сети имеется специальная кнопка. ПО смартфона плотно интегрированно с Facebook.</p><p>Для навигации в сети Интернет HTC Salsa предоставляет полноценный веб-браузер на базе движка WebKit с поддержкой Flash, возможности открытия нескольких вкладок, масштабирования веб-страниц и быстрого доступа к таким сервисам, как Google, Wikipedia или YouTube.</p><p>&nbsp;</p>', 1, 28, 'HTC Salsa', 'HTC Salsa, HTC, Мобильные телефоны', 'HTC Salsa - новый смартфон компании HTC под управлением операционной системы Google Android 2.4. HTC Salsa имеет 3,4-дюймовый WVGA экран с разрешением 480&times;320 пикселей. Габариты устройства составляют 109,1&times;58,9&times;12,3 мм. Смартфон весит 120 граммов. HTC Salsa оснащен 5-ти мегапиксельной камерой с автофокусом и светодиодной вспышкой.', '2011-10-18 17:04:44', 1, '', NULL),
(15, 'blackberry-torch-9800', 6, 'BlackBerry Torch 9800', '<p>BlackBerry (Блэкберри) torch 9800 считают одним из наиболее современных и, конечно же, востребованных мобильных устройств от популярного производителя RIM. Отличительной чертой от большинства конкурентов является то, что телефоны гармонично комбинируют в себе слайдеры со стандартным расположением алфавита (QWERTY), а также сенсорные экраны.</p>', '<p>Torch 9800 базируется на платформе BlackBerry OS 6 и оснащен веб-браузером на движке Webkit. Смартфон выполнен в форм-факторе вертикального слайдера, оснащен сенсорным экраном и выдвигающейся книзу QWERTY-клавиатурой. Устройство обладает 5-МП камерой, 512 МБ ОЗУ, 512 МБ ПЗУ и 4 ГБ дополнительной встроенной памяти, которую можно расширить с помощью карт microSD.</p>', 1, 27, 'BlackBerry Torch 9800', 'BlackBerry Torch 9800, BlackBerry, Мобильные телефоны', 'BlackBerry (Блэкберри) torch 9800 считают одним из наиболее современных и, конечно же, востребованных мобильных устройств от популярного производителя RIM. Отличительной чертой от большинства конкурентов является то, что телефоны гармонично комбинируют в себе слайдеры со стандартным расположением алфавита (QWERTY), а также сенсорные экраны.', '2011-10-18 17:13:44', 0, '', NULL),
(16, 'htc_legend', 4, 'HTC Legend', '<p>HTC Legend &ndash; это смартфон с 3,2-дюймовым сенсорным дисплеем с разрешением 320x480 HVGA. Телефон работает под управлением операционной системы Android. В устройстве не предусмотрена аппаратная клавиатура &ndash; это обыкновенный моноблок-тачфон.</p>', '<p>Аппарат от HTC, несомненно, заслуживает амбициозного названия Legend. Это телефон с крайне удачным сочетанием цены, функционала и качества. Сенсорный AMOLED-экран с диагональю 3.2 дюйма обеспечивает как удобную навигацию, так и комфортный просмотр изображений и видеоматериалов. За быструю работу... приложений отвечает процессор Qualcomm MSM7227 на 600 МГц и оперативная память объемом 384 Мб. Кроме того, в аппарате HTC Legend имеется постоянная память на 512 Мб и слот для карт microSD, позволяющий превратить HTC Legend в портативный плеер или практичный телефон-накопитель. Из крайне важных для такого аппарата функций стоит отметить поддержку USB, Wi-Fi, Bluetooth 2.1.</p>', 1, 26, 'HTC Legend', 'HTC Legend, HTC, Мобильные телефоны', 'HTC Legend &ndash; это смартфон с 3,2-дюймовым сенсорным дисплеем с разрешением 320x480 HVGA. Телефон работает под управлением операционной системы Android. В устройстве не предусмотрена аппаратная клавиатура &ndash; это обыкновенный моноблок-тачфон.', '2011-10-18 17:15:32', NULL, '', NULL),
(17, 'samsung-s7070-diva', 2, 'Samsung S7070 Diva', '<p>Samsung S7070 Diva &mdash; отличный телефон, оснащенный TFT-дисплеем, отображающим до 16 млн. цветов, с диагональю 2.8" и камерой на 3 Mpx, делающей снимки с разрешением 2048 x 1536 px. Оснащен аккумулятором на 960 mAh, который позволяет аппарату работать до 660 часов в режиме ожидания и до 8 в режиме разговора. Для коммуникации может предложить: WAP браузер, EDGE, стерео Bluetooth, и, конечно, USB-порт.</p>', '<p>Одного взгляда на этот телефон достаточно, чтобы понять, что его покупатели - это женщины. Задняя панель сделана из белого рельефного пластика с блестящим оттенком. Лицевая панель украшена серебристыми узорами, а центральная клавиша, выполненная в стиле ограненного бриллианта.</p>', 1, 39, 'Samsung S7070 Diva', 'Samsung S7070 Diva, Samsung, Мобильные телефоны', 'Samsung S7070 Diva &mdash; отличный телефон, оснащенный TFT-дисплеем, отображающим до 16 млн. цветов, с диагональю 2.8" и камерой на 3 Mpx, делающей снимки с разрешением 2048 x 1536 px. Оснащен аккумулятором на 960 mAh, который позволяет аппарату работать до 660 часов в режиме ожидания и до 8 в режиме разговора. Для коммуникации может предложить: WAP браузер, EDGE, стерео Bluetooth, и, конечно, USB-порт.', '2011-10-18 17:16:54', 1, '', NULL),
(18, 'blackberry_bold_9900', 6, 'BlackBerry Bold 9900', '<p>BlackBerry Bold 9900 - выполнен в форм-факторе моноблок с QWERTY-клавиатурой. Имеет 2.8 дюймовый дисплей с разрешением 640 на 480 пикселей, 5 МП камеру с LED вспышкой, 3.5 мм разъём для подключения гарнитуры, поддержку карт памяти microSD, Bluetooth, Wi-Fi и GPS модули.</p>', '<p>BlackBerry Bold 9900 - выполнен в форм-факторе моноблок с QWERTY-клавиатурой. Имеет 2.8 дюймовый дисплей с разрешением 640 на 480 пикселей, 5 МП камеру с LED вспышкой, 3.5 мм разъём для подключения гарнитуры, поддержку карт памяти microSD, Bluetooth, Wi-Fi и GPS модули.</p>', 1, 25, 'BlackBerry Bold 9900', 'BlackBerry Bold 9900, BlackBerry, Мобильные телефоны', 'BlackBerry Bold 9900 - выполнен в форм-факторе моноблок с QWERTY-клавиатурой. Имеет 2.8 дюймовый дисплей с разрешением 640 на 480 пикселей, 5 МП камеру с LED вспышкой, 3.5 мм разъём для подключения гарнитуры, поддержку карт памяти microSD, Bluetooth, Wi-Fi и GPS модули.', '2011-10-18 17:17:55', NULL, '', NULL),
(19, 'sony-ericsson-xperia-x10', 5, 'Sony Ericsson Xperia X10', '<p>Xperia X10 - первый смартфон от компании Sony Ericsson, базирующийся на операционной системе Android. Устройство оснащено сенсорным экраном с диагональю 4 дюйма, разрешением 480 x 854 пикселей и поддержкой 262 тыс. цветовых оттенков.</p>', '<p>Xperia X10 - первый смартфон от компании Sony Ericsson, базирующийся на операционной системе Android. Устройство оснащено сенсорным экраном с диагональю 4 дюйма, разрешением 480 x 854 пикселей и поддержкой 262 тыс. цветовых оттенков. Центральным элементом графического интерфейса Xperia X10 является уникальное приложение Timescape, которое открывает новый способ общения между пользователями. Для того чтобы посмотреть сообщения контакта в социальной сети Facebook, новые записи в Twitter`е, вывести на экран SMS-сообщения или электронную переписку с этим человеком и посмотреть фотографии с его участием, достаточно кликнуть на фотографию контакта, и все данные будут сгруппированы в одном месте. Еще одно приложение - Mediascape - обеспечивает простой и удобный доступ к мультимедийным файлам.</p>', 1, 24, 'Sony Ericsson Xperia X10', 'Sony Ericsson Xperia X10, Sony Ericsson, Мобильные телефоны', 'Xperia X10 - первый смартфон от компании Sony Ericsson, базирующийся на операционной системе Android. Устройство оснащено сенсорным экраном с диагональю 4 дюйма, разрешением 480 x 854 пикселей и поддержкой 262 тыс. цветовых оттенков.', '2011-10-18 17:20:57', 0, '', NULL),
(20, 'nokia-x7', 3, 'Nokia X7', '<p>Защищенный сенсорный смартфон Nokia X7 на базе операционной системы Symbian Anna. Модель отличается брутальным внешним видом, намекая тем самым на повышенную защиту к внешним воздействиям. Для этих целей корпус новинки изготовлен из нержавеющей стали, а дисплей имеет покрытие из закаленного стекла.</p>', '<p>Защищенный сенсорный смартфон Nokia X7 на базе операционной системы Symbian Anna. Модель отличается брутальным внешним видом, намекая тем самым на повышенную защиту к внешним воздействиям. Для этих целей корпус новинки изготовлен из нержавеющей стали, а дисплей имеет покрытие из закаленного стекла. Кроме того, Nokia X7 снабжена 4-х дюймовым сенсорным (емкостным) AMOLED дисплеем разрешением 640х360 точек, 8 МП камерой с поддержкой видеосъемки в разрешении HD, 8 Гб встроенной флэш памятью, 350 Мб (ОЗУ) и слотом под microSD карты памяти. В дополнение ко всему аппарат имеет поддержку GPS навигации и поставляется с комплектом последней версии бесплатного фирменного навигационного ПО Ovi Maps.</p>', 1, 23, 'Nokia X7', 'Nokia X7, Nokia, Мобильные телефоны', 'Защищенный сенсорный смартфон Nokia X7 на базе операционной системы Symbian Anna. Модель отличается брутальным внешним видом, намекая тем самым на повышенную защиту к внешним воздействиям. Для этих целей корпус новинки изготовлен из нержавеющей стали, а дисплей имеет покрытие из закаленного стекла.', '2011-10-18 17:25:55', 0, '', NULL),
(21, 'nokia-c2-03', 3, 'Nokia C2-03', '<p>Nokia C2-03 - отличный телефон, работающий на платформе Series 40 6th Edition (initial release), оснащенный TFT-дисплеем, отображающим до 65 тыс. цветов, с диагональю 2.6" и камерой на 2 Mpx, делающей снимки с разрешением 1600 x 1200 px.</p>', '<p>Nokia C2-03 - отличный телефон, работающий на платформе Series 40 6th Edition (initial release), оснащенный TFT-дисплеем, отображающим до 65 тыс. цветов, с диагональю 2.6" и камерой на 2 Mpx, делающей снимки с разрешением 1600 x 1200 px. Оснащен мощным аккумулятором на 1020 mAh, который позволяет аппарату работать до 400 часов в режиме ожидания и до 5 в режиме разговора. Для коммуникации может предложить: Web-браузер, EDGE, стерео Bluetooth, и, конечно, USB-порт. Для любителей музыки есть аудио выход на 3.5 мм.</p>', 1, 22, 'Nokia C2-03', 'Nokia C2-03, Nokia, Мобильные телефоны', 'Nokia C2-03 - отличный телефон, работающий на платформе Series 40 6th Edition (initial release), оснащенный TFT-дисплеем, отображающим до 65 тыс. цветов, с диагональю 2.6" и камерой на 2 Mpx, делающей снимки с разрешением 1600 x 1200 px.', '2011-10-18 17:27:25', 0, '', NULL),
(22, 'samsung-s3350', 2, 'Samsung S3350', '<p>Samsung S3350, он же Ch@t 335 (для Европы), относится к категррии "недорогой QWERTY-моноблок для молодых любителей початиться". Имеет приложение для доступа к Facebook и Twitter, работает с различными службами сообщений: MSN, Yahoo, Gtalk, uTalk, Facebook, AOL, Bluetooth Messenger.</p>', '<p>Samsung S3350, он же Ch@t 335 (для Европы), относится к категррии "недорогой QWERTY-моноблок для молодых любителей початиться". Имеет приложение для доступа к Facebook и Twitter, работает с различными службами сообщений: MSN, Yahoo, Gtalk, uTalk, Facebook, AOL, Bluetooth Messenger. Функционалом не блещет, хотя WiFi поддерживает. В остальном характеристики средненькие. Оформление корпуса "под металл".</p>', 1, 21, 'Samsung S3350', 'Samsung S3350, Samsung, Мобильные телефоны', 'Samsung S3350, он же Ch@t 335 (для Европы), относится к категррии "недорогой QWERTY-моноблок для молодых любителей початиться". Имеет приложение для доступа к Facebook и Twitter, работает с различными службами сообщений: MSN, Yahoo, Gtalk, uTalk, Facebook, AOL, Bluetooth Messenger.', '2011-10-18 17:30:28', 0, '', NULL),
(23, 'nokia-x6-16gb', 3, 'Nokia X6 16Gb', '<p>Мобильный телефон Nokia Х6 16 GB относится к музыкальным смартфонам и является очередной флагманской моделью от финской компании Nokia. Он и оснащен всеми инновационными технологиями и является первой моделью с емкостным дисплеем.</p>', '<p>Мобильный телефон Nokia Х6 16 GB относится к музыкальным смартфонам и является очередной флагманской моделью от финской компании Nokia. Он и оснащен всеми инновационными технологиями и является первой моделью с емкостным дисплеем.</p>', 1, 20, 'Nokia X6 16Gb', 'Nokia X6 16Gb, Nokia, Мобильные телефоны', 'Мобильный телефон Nokia Х6 16 GB относится к музыкальным смартфонам и является очередной флагманской моделью от финской компании Nokia. Он и оснащен всеми инновационными технологиями и является первой моделью с емкостным дисплеем.', '2011-10-18 17:32:04', 0, '', NULL),
(24, 'samsung-s3650-corby', 2, 'Samsung S3650 Corby', '<p>Пришла эра сенсорных телефонов. Теперь не нужно отказывать себе в чем-то, чтобы накопить на настоящий тачфон. Достаточно обратить внимание на Samsung S3650 Corby. Да, он действительно настолько доступный, при этом обладает стильным внешним видом и хорошим функционалом.</p>', '<p>Пришла эра сенсорных телефонов. Теперь не нужно отказывать себе в чем-то, чтобы накопить на настоящий тачфон. Достаточно обратить внимание на Samsung S3650 Corby. Да, он действительно настолько доступный, при этом обладает стильным внешним видом и хорошим функционалом. Если вы цените удобство, даримое сенсорным экраном, но не планируете платить за это баснословные деньги, перед вами - идеальный выбор.</p>', 1, 19, 'Samsung S3650 Corby', 'Samsung S3650 Corby, Samsung, Мобильные телефоны', 'Пришла эра сенсорных телефонов. Теперь не нужно отказывать себе в чем-то, чтобы накопить на настоящий тачфон. Достаточно обратить внимание на Samsung S3650 Corby. Да, он действительно настолько доступный, при этом обладает стильным внешним видом и хорошим функционалом.', '2011-10-18 17:33:51', 1, '', NULL),
(26, 'nokia-6700-classic-illuvial', 3, 'Nokia 6700 classic Illuvial', '<p>Nokia 6700 Classic Illuvial сумел соединить в себе завидную функциональность и стильные необыкновенно женственные формы. Дизайн телефона выполнен в розово-черных тонах - это, несомненно, привлечет к устройству повышенный интерес со стороны прекрасной половины человечества.</p>', '<p>Nokia 6700 Classic Illuvial сумел соединить в себе завидную функциональность и стильные необыкновенно женственные формы. Дизайн телефона выполнен в розово-черных тонах - это, несомненно, привлечет к устройству повышенный интерес со стороны прекрасной половины человечества. Специальное ПО продолжает тему разового и черного цветов. В Нокии 6700 classic illuvial установлены специальные обои, темы и рингтоны, разработанные ведущими дизайнерами,<br />программистами и композиторами специально для этой серии телефонов. Комплект поставки аппарата приятно удивит милых дам. В коробке вместе с телефоном они найдут фирменный сюрприз - потрясающее украшение!</p>', 1, 17, 'Nokia 6700 classic Illuvial', 'Nokia 6700 classic Illuvial, Nokia, Мобильные телефоны', 'Nokia 6700 Classic Illuvial сумел соединить в себе завидную функциональность и стильные необыкновенно женственные формы. Дизайн телефона выполнен в розово-черных тонах - это, несомненно, привлечет к устройству повышенный интерес со стороны прекрасной половины человечества.', '2011-10-18 17:45:38', 0, '', NULL),
(27, 'blackberry-torch-9810', 6, 'BlackBerry Torch 9810', '<p>Телефон выполнен в формфакторе вертикального QWERTY-слайдер и целиком повторяет дизайн своего родоначальника. Впрочем, улучшения есть. Так, всё тот же 3,2-дюймовый сенсорный экран модернизировал пиксельную матрицу с 480x360 до 640x480 точек.</p>', '<p>Телефон выполнен в формфакторе вертикального QWERTY-слайдер и целиком повторяет дизайн своего родоначальника. Впрочем, улучшения есть. Так, всё тот же 3,2-дюймовый сенсорный экран модернизировал пиксельную матрицу с 480x360 до 640x480 точек. За вычисления теперь отвечает одноядерный 1,2-ГГц процессор с видеографическим кристаллом, а 5-Мпикс камера научилась снимать 720p-видео.<br />Прочие технические параметры BlackBerry Torch 9810, заключенного в уже устаревший корпус толщиной 14,6 мм и массой 161 г, таковы: 768 Мбайт оперативной памяти, 8 Гбайт встроенного флеш-хранилища плюс слот для microSD-карт, коммуникации GSM/HSPA, NFC, A-GPS, Wi-Fi 802.11b/g/n и Bluetooth 2.1, порт microUSB 2.0 и 3,5-мм аудиовыход. Автономность съемной 1270-мАч батареи заявлена в пределах 5,9-6,5 ч разговора.</p>', 1, 16, 'BlackBerry Torch 9810', 'BlackBerry Torch 9810, BlackBerry, Мобильные телефоны', 'Телефон выполнен в формфакторе вертикального QWERTY-слайдер и целиком повторяет дизайн своего родоначальника. Впрочем, улучшения есть. Так, всё тот же 3,2-дюймовый сенсорный экран модернизировал пиксельную матрицу с 480x360 до 640x480 точек.', '2011-10-18 17:52:42', 0, '', NULL),
(28, 'nokia-701', 3, 'Nokia 701', '<p>Классический нокиевский тачфон, достаточно серьезный набор характеристик, но камера все равно не автофокусная. Поддерживает NFC и предполагает широкое использование этой технологии - для спаривания с гарнитурой, обмена информацией с другими аппаратами, игр.</p>', '<p>Классический нокиевский тачфон, достаточно серьезный набор характеристик, но камера все равно не автофокусная. Поддерживает NFC и предполагает широкое использование этой технологии - для спаривания с гарнитурой, обмена информацией с другими аппаратами, игр.</p>', 1, 15, 'Nokia 701', 'Nokia 701, Nokia, Мобильные телефоны', 'Классический нокиевский тачфон, достаточно серьезный набор характеристик, но камера все равно не автофокусная. Поддерживает NFC и предполагает широкое использование этой технологии - для спаривания с гарнитурой, обмена информацией с другими аппаратами, игр.', '2011-10-18 18:03:46', 0, '', NULL),
(29, 'pylesos-dyson-dc23-pink', 7, 'Пылесос Dyson DC23 Pink', '<p>Щетка с независимым электродвигателем для более глубокой очистки ковровых покрытий. Частота вращения валиков - 5400 об/мин. Оборудована системой автоматического отключения при попадании постороннего и предмета или возникновении засора.</p>', '<p>Щетка с независимым электродвигателем для более глубокой очистки ковровых покрытий. Частота вращения валиков - 5400 об/мин. Оборудована системой автоматического отключения при попадании постороннего и предмета или возникновении засора.</p><p align="justify" class="lgr">ХЕПА фильтр с антибактериальной пропиткой Bactisafe удерживает и убивает бактерии и аллергены. Воздух, исходящий из пылесоса Dyson содержит до 150 раз меньше бактерий и аллергенов, чем воздух, которым Вы дышите.</p><p align="justify" class="lgr">Телескопическая труба и шланг складываются и крепятся на корпусе. В таком виде пылесос легко переносить и удобно хранить.</p><p>&nbsp;</p>', 1, 14, 'Пылесос Dyson DC23 Pink', 'Пылесос Dyson DC23 Pink, Dyson, Пылесосы', 'Щетка с независимым электродвигателем для более глубокой очистки ковровых покрытий. Частота вращения валиков - 5400 об/мин. Оборудована системой автоматического отключения при попадании постороннего и предмета или возникновении засора.', '2011-10-22 13:09:05', 0, '', NULL),
(30, 'pylesos-dyson-dc32-animalpro', 7, 'Пылесос Dyson DC32 AnimalPro', '<p>Пылесос Dyson DC32 Animal Pro - новый и мощный пылесос с ярким дизайном, предназначен для тщательной уборки шерсти домашних животных.</p>', '<p><span>Пылесос Dyson DC32 Animal Pro - новый и мощный пылесос с ярким дизайном, предназначен для тщательной уборки шерсти домашних животных. Специальная тубощётка &laquo;Turbo&raquo; с высокой частотой вращения валиков, максимально эффективно удаляет и проводит глубокую очистку въевшейся грязи и шерсти домашних животных с ковровых покрытий.</span></p>', 1, 13, 'Пылесос Dyson DC32 AnimalPro', 'Пылесос Dyson DC32 AnimalPro, Dyson, Пылесосы', 'Пылесос Dyson DC32 Animal Pro - новый и мощный пылесос с ярким дизайном, предназначен для тщательной уборки шерсти домашних животных.', '2011-10-22 13:13:18', 0, '', NULL),
(31, 'pylesos-electrolux-zt-3510', 8, 'Пылесос Electrolux ZT 3510', '<p>Проверенная временем, циклоническая технология фильтрации применяется в пылесосе ELECTROLUX ZT 3510. Циклонирование, обеспечивает ZT 3510 постоянно высокую мощность всасывания, мало зависимую от степени заполнения контейнера для пыли.</p>', '<p>Проверенная временем, циклоническая технология фильтрации применяется в пылесосе ELECTROLUX ZT 3510. Циклонирование, обеспечивает ZT 3510 постоянно высокую мощность всасывания, мало зависимую от степени заполнения контейнера для пыли.<br />Промывной HEPA фильтр, закрыт предварительным пластиковым отсекателем крупной пыли, за счет чего, HEPA фильтр не нуждается в частой промывки и очистке.<br />Циклонический контейнер, благодаря продуманной фиксирующей защелке, одним движением открывается и легко опорожняется от собранной пыли в мусорное ведро. Прочный пластик корпуса и силиконовый шланг пылесоса, дают основание не сомневаться в прочности ZT 3510, а отсутствие расходных элементов, позволит избежать лишних финансовых и временных потерь, своему владельцу.</p>', 1, 12, 'Пылесос Electrolux ZT 3510', 'Пылесос Electrolux ZT 3510, Electrolux, Пылесосы', 'Проверенная временем, циклоническая технология фильтрации применяется в пылесосе ELECTROLUX ZT 3510. Циклонирование, обеспечивает ZT 3510 постоянно высокую мощность всасывания, мало зависимую от степени заполнения контейнера для пыли.', '2011-10-22 13:31:49', 0, '', NULL),
(32, 'pylesos-dyson-dc22-motorhead', 7, 'Пылесос Dyson DC22 Motorhead', '<p>Dyson DC22 Motorhead самый многофункциональный пылесос из серии пылесосов DC 22. В нем соединены все практически функции для уборки.</p>', '<p>Dyson DC22 Motorhead самый многофункциональный пылесос из серии пылесосов DC 22. В нем соединены все практически функции для уборки. Вам нужно убрать под ступеньками лестницы или снять пыль с карнизов, Dyson DC22 Motorhead с легкостью достает все труднодоступные места и при этом очищает воздух от бактерий, пыли и аллергенов.</p><p>У Вас есть домашние животные и часто необходимо убирать шерсть и поддерживать чистоту? Для этого пылесоса нет преград! Мощные насадки и щетка, вычистит самый грязный ковер. При попадании постороннего предмета в пылесос сразу же срабатывает система автоматического отключения. Сам пылесос легкий и компактный. Для него всегда найдется место в Вашем доме. Такой пылесос легко может претендовать на незаменимого друга по уборке в Вашем доме.</p><p>&nbsp;</p>', 1, 11, 'Пылесос Dyson DC22 Motorhead', 'Пылесос Dyson DC22 Motorhead, Dyson, Пылесосы', 'Dyson DC22 Motorhead самый многофункциональный пылесос из серии пылесосов DC 22. В нем соединены все практически функции для уборки.', '2011-10-22 13:35:47', 0, '', NULL),
(33, 'dyson-dc32-exclusive', 7, 'Dyson DC32 Exclusive', '<p>Пылесос Dyson DC32 EXCLUSIVE - является машиной, основное предназначение которой, сбор пыли, удаление мусора, а также грязи. Пылесос может, например, чистить любые ковровые изделия, а также убирает мусор с пола в квартире. Очень не сложен в использовании на практике.</p>', '<p>Пылесос Dyson DC32 EXCLUSIVE - является машиной, основное предназначение которой, сбор пыли, удаление мусора, а также грязи. Пылесос может, например, чистить любые ковровые изделия, а также убирает мусор с пола в квартире. Очень не сложен в использовании на практике.</p>', 1, 10, 'Dyson DC32 Exclusive', 'Dyson DC32 Exclusive, Dyson, Пылесосы', 'Пылесос Dyson DC32 EXCLUSIVE - является машиной, основное предназначение которой, сбор пыли, удаление мусора, а также грязи. Пылесос может, например, чистить любые ковровые изделия, а также убирает мусор с пола в квартире. Очень не сложен в использовании на практике.', '2011-10-22 13:38:03', 0, '', NULL),
(34, 'mikser-zelmer-48167', 9, 'Миксер Zelmer 481.67', '<p>Современная модель миксера Zelmer 481.67. Эффективное сочетание компактного размера и высокой мощности. Миксер универсален. Отличается от других моделей серии тем, что оснащен встроенными в чашу весами с LCD - дисплеем.</p>', '<p>Современная модель миксера Zelmer 481.67. Эффективное сочетание компактного размера и высокой мощности. Миксер универсален. Отличается от других моделей серии тем, что оснащен встроенными в чашу весами с LCD - дисплеем. Вы всегда будет знать количество взбиваемых продуктов! Хотите сэкономить - приобретите эту модель и наслаждайтесь комфортным и быстрым приготовлением пищи! При работе на подставке миксер Zelmer 481.67 совершает колебательные движения, равномерно перемешивающие продукты, а вращающаяся чаша распределяет их до однородной массы. Специально предусмотренная функция блендера является одним из дополнительных плюсов этого миксера. В комплект поставки входят разнообразные насадки: насадка для протирания овощей, венчики и мешалки из нержавеющей стали, для перемешивания и взбивания, лопатка и шпатель, устанавливающийся на чашу, для свободного перемешивания теста. Также в комплект входит стакан для блендера. Емкость рабочей чаши составляет 3 литра. Предусмотрены 5 скоростей для различных режимов работы. Максимальные предел взвешивания для весов 3 кг.</p>', 1, 9, 'Миксер Zelmer 481.67', 'Миксер Zelmer 481.67, Zelmer, Миксеры', 'Современная модель миксера Zelmer 481.67. Эффективное сочетание компактного размера и высокой мощности. Миксер универсален. Отличается от других моделей серии тем, что оснащен встроенными в чашу весами с LCD - дисплеем.', '2011-10-23 10:57:46', 0, '', NULL),
(35, 'mikser_zelmer_48164', 9, 'Миксер Zelmer 481.64', '<p>Вкусные муссы, кремы, десерты и домашние торты Вам обеспечены со стационарным миксером Zelmer 481.64. Он прост и удобный в обращении, предоставляет для быстрого смешивания продуктов 5 уровней скорости плюс турбо режим.</p>', '<p>Вкусные муссы, кремы, десерты и домашние торты Вам обеспечены со стационарным миксером Zelmer 481.64. Он прост и удобный в обращении, предоставляет для быстрого смешивания продуктов 5 уровней скорости плюс турбо режим. В качестве инструментов используются две насадки: венчик для взбивания, крюки для теста, которые извлекаются из корпуса простым нажатием на кнопку. Также эта модель имеет вращающуюся чашу объемом 3 литра изготовленную и пластика.</p>', 1, 8, 'Миксер Zelmer 481.64', 'Миксер Zelmer 481.64, Zelmer, Миксеры', 'Вкусные муссы, кремы, десерты и домашние торты Вам обеспечены со стационарным миксером Zelmer 481.64. Он прост и удобный в обращении, предоставляет для быстрого смешивания продуктов 5 уровней скорости плюс турбо режим.', '2011-10-23 11:02:08', NULL, '', NULL),
(36, 'mikser_zelmer_4814', 9, 'Миксер Zelmer 481.4', '<p>Современный, мультифункциональный миксер ZELMER 481.4 сочетает в себе максимум функций для приготовления тортов, пирожных, коктейлей, кремов и других вкусных блюд.</p>', '<p>Современный, мультифункциональный миксер ZELMER 481.4 сочетает в себе максимум функций для приготовления тортов, пирожных, коктейлей, кремов и других вкусных блюд. 5 уровней скорости позволяют выбирать мощность в зависимости от задачи. Открытая ручка миксера с противоскользящее покрытием позволяет работать с миксером даже когда вы берете его мокрыми руками. Мощность: 400 Вт. 2 венчика для взбивания из нержавеющей стали. Турборежим.</p>', 1, 7, 'Миксер Zelmer 481.4', 'Миксер Zelmer 481.4, Zelmer, Миксеры', 'Современный, мультифункциональный миксер ZELMER 481.4 сочетает в себе максимум функций для приготовления тортов, пирожных, коктейлей, кремов и других вкусных блюд.', '2011-10-23 11:05:41', NULL, '', NULL),
(37, 'fotoapparat-nikon-coolpix-s100', 10, 'Фотоаппарат Nikon Coolpix S100', '<p>Матрица 1/2.3" CMOS, 16 мп / объектив NIKKOR / поддержка карт памяти SD/SDHC/SDXC / сенсорный 3.5" OLED / Full HD-видео / питание от литий-ионного аккумулятора / 181 x 990 x 652 мм, 138 г / красный</p>', '<p>Изящная фотокамера с мультисенсорным управлением. Отличное сочетание утонченного стиля и высоких технологий совершенства, фотокамера COOLPIX S100 оснащена множеством функций, которые позволяют легко добиться фантастических результатов. <br />Мультисенсорная панель управления мгновенно реагирует на прикосновения пальцев, обеспечивая невероятно удобное использование фотокамеры. ОСИД-экран (OLED) высокого разрешения воспроизводит каждую деталь каждого снимка, обеспечивая впечатляющую чистоту, яркость и воспроизведение цвета. 16-мегапиксельная КМОП-матрица с обратной подсветкой гарантирует превосходные результаты при любом освещении, а такие инновационные функции, как режим съемки 3D позволит весело экспериментировать со съемкой окружающего мира.</p>', 1, 6, 'Фотоаппарат Nikon Coolpix S100', 'Фотоаппарат Nikon Coolpix S100, Nikon, Фотоаппараты', 'Матрица 1/2.3" CMOS, 16 мп / объектив NIKKOR / поддержка карт памяти SD/SDHC/SDXC / сенсорный 3.5" OLED / Full HD-видео / питание от литий-ионного аккумулятора / 181 x 990 x 652 мм, 138 г / красный', '2011-12-23 11:49:23', 0, '', NULL),
(38, 'fotoapparat-nikon-coolpix-l23', 10, 'Фотоаппарат Nikon Coolpix L23', '<p>Матрица 1/2.9", 10,1 Мп / Зум: 5x (оптический) / поддержка карт памяти SD / LCD-дисплей 2,7" / питание от двух батареек типа АА / 96,7 x 59,9 x 29,3 мм, 170 г / черный</p>', '<p>Идеальная фотокамера для начинающего фотографа, COOLPIX L23 оснащена множеством автоматических технологий для превосходной упрощенной съемки.</p><p>Где бы вы ни были и что бы ни снимали, простой авторежим оптимизирует все настройки фотокамеры для получения великолепных результатов - задуманный снимок все равно получится.</p><p>Широкоугольный 5-кратный зум-объектив позволяет легко запечатлеть что угодно, от резких макроснимков до прекрасных групповых фотографий, а система интеллектуального портрета от компании Nikon обеспечивает неизменно идеальную портретную съемку. Фотокамера совместима с батареями типоразмера AA и оснащена тонким корпусом, легко заряжается и переносится в любых условиях.</p><p>&nbsp;</p>', 1, 5, 'Фотоаппарат Nikon Coolpix L23', 'Фотоаппарат Nikon Coolpix L23, Nikon, Фотоаппараты', 'Матрица 1/2.9", 10,1 Мп / Зум: 5x (оптический) / поддержка карт памяти SD / LCD-дисплей 2,7" / питание от двух батареек типа АА / 96,7 x 59,9 x 29,3 мм, 170 г / черный', '2011-10-23 11:41:10', 0, '', NULL);
INSERT INTO `s_products` (`id`, `url`, `brand_id`, `name`, `annotation`, `body`, `visible`, `position`, `meta_title`, `meta_keywords`, `meta_description`, `created`, `featured`, `external_id`, `update`) VALUES
(39, 'fotoapparat-nikon-coolpix-l120', 10, 'Фотоаппарат Nikon Coolpix L120', '<p>Матрица 1/2,3", 14 Мп / Зум 21х (оптический) / поддержка карт памяти SD/MMC / ЖК-дисплей 3" / питание от четырех батареек типа АА / 109,9 x 76,5 x 78,4 мм, 431 г</p>', '<p>Благодаря фотокамере COOLPIX L120 создавать потрясающие снимки и записывать видеоролики высокой четкости стало еще проще. Оптимизированная для создания удивительных изображений, она оснащена 21-кратным зум-объективом NIKKOR, который обеспечивает точное покрытие всего диапазона - от широкоугольного до супертелескопического. Четыре различные функции уменьшения смазывания позволяют автоматически получить резкие результаты. Также фотокамера имеет боковой рычажок зуммирования, плавно работающий во всем 21-кратном диапазоне.</p><p>Специальная кнопка видеосъемки помогает переключаться в режим записи действия, а на большом ЖК мониторе с высоким разрешением можно легко компоновать и просматривать кадры даже при ярком солнечном свете.</p><p>&nbsp;</p>', 1, 4, 'Фотоаппарат Nikon Coolpix L120', 'Фотоаппарат Nikon Coolpix L120, Nikon, Фотоаппараты', 'Матрица 1/2,3", 14 Мп / Зум 21х (оптический) / поддержка карт памяти SD/MMC / ЖК-дисплей 3" / питание от четырех батареек типа АА / 109,9 x 76,5 x 78,4 мм, 431 г', '2011-11-23 11:49:23', 0, '', NULL),
(40, 'fotoapparat-nikon-coolpix-s2500', 10, 'Фотоаппарат Nikon Coolpix S2500', '<p>Матрица 1/2.3", 12 Мп / Зум: 4x (оптический) / поддержка карт памяти SD / LCD-дисплей 2.7" / питание от литий-ионного аккумулятора / 93 x 57 x 20 мм, 117 г</p>', '<p>Фотокамера Nikon Coolpix S2500, выполненная в сверхтонком корпусе, оснащена высокоточным широкоугольным Zoom-объективом и 12,1-мегапиксельной матрицей, за счет чего можно достичь невероятной детализации изображений. Многочисленные интеллектуальные режимы аппарата позволят любому пользователю, вне зависимости от опыта, сделать отличные снимки. А усовершенствованные автоматические функции, которыми снабжена фотокамера Nikon Coolpix S2500, станут большим подспорьем при создании портретов. Таймер улыбки, например, поможет сделать снимок, когда выбранный объект улыбается, а функция отслеживания моргания предупреждает о том, что у героя кадра закрыты глаза. Кроме того, аппарат умеет записывать видеоролики со звуком, что делает его еще более функциональным.</p>', 1, 3, 'Фотоаппарат Nikon Coolpix S2500', 'Фотоаппарат Nikon Coolpix S2500, Nikon, Фотоаппараты', 'Матрица 1/2.3", 12 Мп / Зум: 4x (оптический) / поддержка карт памяти SD / LCD-дисплей 2.7" / питание от литий-ионного аккумулятора / 93 x 57 x 20 мм, 117 г', '2011-10-23 11:52:33', 0, '', NULL),
(41, 'fotoapparat-canon-powershot-a3200-is', 11, 'Фотоаппарат Canon PowerShot A3200 IS', '<p>Матрица 1/2.3", 14.1 Мп / Зум: 5х (оптический), 4х (цифровой) / поддержка карт памяти SD/MMC / LCD-дисплей 2.7" / HD-видео / питание от литий-ионного аккумулятора / 95.1 x 56.7 x 24.3 мм, 149 г</p>', '<p>Бюджетная компактная камера с металлическим корпусом, которая оптимально подойдет для не требовательных фотографов. Потому что у нее минимальные возможности для творческой съемки и не самое блестящее качество снимков. С другой стороны, Canon PowerShot A3200 IS снимает все нажатием одной кнопки, не будет отягощать большим весом и доступна по невысокой цене. В отличие от аналогов, эта модель имеет механизм оптической стабилизации, поэтому риск получить не резкие снимки невелик. Широкоугольный объектив хорошо снимает как удаленные объекты без приближения (например, пейзажи), так и те, что вблизи (например, людей на вечеринке). Также эта модель радует съемкой видео в хорошем качестве (HD 720p). От модели A3300 IS отличается меньшими дисплеем и разрешением матрицы. Модель доступна в серебристой, оранжевой и розовой расцветке.</p>', 1, 2, 'Фотоаппарат Canon PowerShot A3200 IS', 'Фотоаппарат Canon PowerShot A3200 IS, Canon, Фотоаппараты', 'Матрица 1/2.3", 14.1 Мп / Зум: 5х (оптический), 4х (цифровой) / поддержка карт памяти SD/MMC / LCD-дисплей 2.7" / HD-видео / питание от литий-ионного аккумулятора / 95.1 x 56.7 x 24.3 мм, 149 г', '2011-12-23 09:49:23', 0, '', NULL),
(42, 'fotoapparat-canon-digital-ixus-1000-hs', 11, 'Фотоаппарат Canon Digital IXUS 1000 HS', '<p>Матрица 1/2.3", 10 Мп / Зум: 10х (оптический), 4х (цифровой) / поддержка карт памяти SD/SDHC / LCD-дисплей 3" / FullHD-видео (1920x1080, 24 кадра/с) / питание от литий-ионного аккумулятора / 101,3x58,5x22,3 мм, 190 г</p>', '<p>Камера IXUS 1000 HS выполнена в серебристом, коричневом или розовом цвете и является одной из самых совершенных моделей IXUS на сегодняшний день, представляя собой пример передовых инновационных решений, которые неизменно присутствуют в каждом поколении камер IXUS. Компактная камера оснащена объективом с мощным 10-кратным оптическим зумом и является самой тонкой камерой с суперзумом в мире 1, а функция записи видео в режиме Full HD позволяет создавать качественные фильмы с разрешением 1080p. Камера имеет высокочувствительную 10-мегапиксельную матрицу CMOS с мощным процессором DIGIC 4 для съёмки на высокой скорости и создания великолепных фотографий. Кроме того, это уже вторая модель IXUS, оснащённая системой HS System.</p>', 1, 1, 'Фотоаппарат Canon Digital IXUS 1000 HS', 'Фотоаппарат Canon Digital IXUS 1000 HS, Canon, Фотоаппараты', 'Матрица 1/2.3", 10 Мп / Зум: 10х (оптический), 4х (цифровой) / поддержка карт памяти SD/SDHC / LCD-дисплей 3" / FullHD-видео (1920x1080, 24 кадра/с) / питание от литий-ионного аккумулятора / 101,3x58,5x22,3 мм, 190 г', '2011-10-23 12:06:26', 0, '', NULL),
(95, 'vasia', 1, 'Васиа', '', '', 1, 1, 'Васиа', 'Васиа, Apple', 'Васиа', '2016-06-15 14:42:07', NULL, '', '2016-06-17 18:32:07');

-- --------------------------------------------------------

--
-- Структура таблицы `s_products_categories`
--

DROP TABLE IF EXISTS `s_products_categories`;
CREATE TABLE IF NOT EXISTS `s_products_categories` (
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `position` int(11) DEFAULT '1',
  PRIMARY KEY (`product_id`,`category_id`),
  KEY `position` (`position`),
  KEY `product_id` (`product_id`),
  KEY `category_id` (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_products_categories`
--

INSERT INTO `s_products_categories` (`product_id`, `category_id`, `position`) VALUES
(1, 1, 1),
(2, 1, 0),
(3, 1, 0),
(4, 1, 0),
(5, 1, 0),
(6, 1, 0),
(7, 1, 0),
(8, 1, 0),
(9, 1, 0),
(10, 1, 0),
(11, 1, 0),
(12, 1, 0),
(13, 1, 0),
(14, 1, 0),
(15, 1, 0),
(16, 1, 0),
(17, 1, 0),
(18, 1, 0),
(19, 1, 0),
(20, 1, 0),
(21, 1, 0),
(22, 1, 0),
(23, 1, 0),
(24, 1, 0),
(25, 1, 0),
(26, 1, 0),
(27, 1, 0),
(28, 1, 0),
(29, 3, 0),
(30, 3, 0),
(31, 3, 0),
(32, 3, 0),
(33, 3, 0),
(34, 4, 0),
(35, 4, 0),
(36, 4, 0),
(37, 5, 0),
(38, 5, 0),
(39, 5, 0),
(40, 5, 0),
(41, 5, 0),
(42, 5, 0),
(44, 2, 1),
(44, 3, 1),
(44, 4, 1),
(56, 3, 1),
(52, 2, 1),
(52, 3, 1),
(56, 1, 1),
(56, 4, 1),
(62, 3, 1),
(62, 1, 1),
(62, 4, 1),
(65, 1, 1),
(65, 3, 1),
(66, 3, 1),
(66, 2, 1),
(1, 2, 1),
(66, 4, 1),
(67, 2, 1),
(74, 2, 1),
(74, 3, 1),
(75, 2, 1),
(75, 3, 1),
(76, 2, 1),
(76, 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `s_purchases`
--

DROP TABLE IF EXISTS `s_purchases`;
CREATE TABLE IF NOT EXISTS `s_purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL DEFAULT '0',
  `product_id` int(11) DEFAULT '0',
  `variant_id` int(11) DEFAULT NULL,
  `product_name` varchar(255) NOT NULL DEFAULT '',
  `variant_name` varchar(255) NOT NULL,
  `price` float(10,2) NOT NULL DEFAULT '0.00',
  `amount` int(11) NOT NULL DEFAULT '0',
  `sku` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `variant_id` (`variant_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_purchases`
--

INSERT INTO `s_purchases` (`id`, `order_id`, `product_id`, `variant_id`, `product_name`, `variant_name`, `price`, `amount`, `sku`) VALUES
(1, 1, 28, 36, 'Nokia 701', '', 17000.00, 1, ''),
(2, 1, 4, 5, 'HTC Sensation', '', 20300.00, 1, ''),
(3, 2, 2, 3, 'Samsung Galaxy S II', '', 19200.00, 1, ''),
(4, 21, 2, 3, 'Samsung Galaxy S II', '', 19200.00, 79, ''),
(5, 22, 2, 3, 'Samsung Galaxy S II', '', 19200.00, 79, ''),
(6, 22, 39, 47, 'Фотоаппарат Nikon Coolpix L120', '', 11000.00, 1, ''),
(7, 22, 40, 48, 'Фотоаппарат Nikon Coolpix S2500', '', 3200.00, 1, ''),
(8, 22, 76, 53, 'Васиа', '314', 32434.00, 1, '32432'),
(9, 24, 4, 5, 'HTC Sensation', '', 20300.00, 7, ''),
(10, 28, 3, 4, 'HTC Incredible S', '', 16000.00, 1, ''),
(11, 29, 3, 4, 'HTC Incredible S', '', 16000.00, 1, ''),
(12, 29, 4, 5, 'HTC Sensation', '', 20300.00, 1, ''),
(13, 30, 3, 4, 'HTC Incredible S', '', 16000.00, 1, ''),
(14, 30, 4, 5, 'HTC Sensation', '', 20300.00, 1, ''),
(15, 31, 2, 3, 'Samsung Galaxy S II', '', 19200.00, 1, ''),
(16, 31, 3, 4, 'HTC Incredible S', '', 16000.00, 1, '');

-- --------------------------------------------------------

--
-- Структура таблицы `s_related_products`
--

DROP TABLE IF EXISTS `s_related_products`;
CREATE TABLE IF NOT EXISTS `s_related_products` (
  `product_id` int(11) NOT NULL,
  `related_id` int(11) NOT NULL,
  `position` int(11) DEFAULT '1',
  PRIMARY KEY (`product_id`,`related_id`),
  KEY `position` (`position`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_related_products`
--

INSERT INTO `s_related_products` (`product_id`, `related_id`, `position`) VALUES
(37, 39, 0),
(37, 40, 1),
(39, 41, 0),
(39, 42, 1),
(41, 41, 0),
(41, 40, 3),
(41, 39, 1),
(41, 37, 2),
(29, 32, 1),
(29, 30, 0),
(33, 30, 1),
(33, 29, 0),
(30, 33, 0),
(30, 29, 1),
(2, 16, 0),
(2, 14, 1),
(2, 3, 2),
(8, 24, 1),
(8, 17, 0),
(8, 21, 2),
(17, 8, 0),
(17, 24, 1),
(17, 21, 2),
(67, 3, 1),
(66, 1, 1),
(66, 3, 1),
(66, 2, 1),
(67, 2, 1),
(67, 4, 1),
(74, 2, 1),
(75, 3, 1),
(0, 2, 1),
(76, 3, 1),
(74, 3, 1),
(75, 2, 1),
(74, 4, 1),
(76, 2, 1),
(76, 4, 1),
(76, 1, 1),
(76, 6, 1),
(75, 4, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `s_settings`
--

DROP TABLE IF EXISTS `s_settings`;
CREATE TABLE IF NOT EXISTS `s_settings` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=MyISAM AUTO_INCREMENT=120 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_settings`
--

INSERT INTO `s_settings` (`setting_id`, `name`, `value`) VALUES
(8, 'site_name', 'Великолепный интернет-магазин'),
(9, 'company_name', 'ООО "Великолепный интернет-магазин"'),
(50, 'units', 'шт'),
(53, 'date_format', 'd.m.Y'),
(54, 'order_email', 'me@example.com'),
(55, 'comment_email', 'me@example.com'),
(56, 'notify_from_email', 'me@example.com'),
(57, 'decimals_point', ','),
(58, 'thousands_separator', ' '),
(59, 'products_num', '24'),
(60, 'products_num_admin', '20'),
(30, 'theme', 'default'),
(33, 'products_num', '24'),
(34, 'products_num_admin', '20'),
(111, 'last_1c_orders_export_date', '2011-07-30 21:31:56'),
(112, 'license', 'bhbcfgkhfe iomjlglmpl rqwqxrtpz6 898495c7 cfee'),
(113, 'max_order_amount', '50'),
(114, 'watermark_offset_x', '50'),
(115, 'watermark_offset_y', '50'),
(116, 'watermark_transparency', '50'),
(117, 'images_sharpen', '15'),
(119, 'admin_email', 'me@example.com');

-- --------------------------------------------------------

--
-- Структура таблицы `s_user`
--

DROP TABLE IF EXISTS `s_user`;
CREATE TABLE IF NOT EXISTS `s_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `auth_key` varchar(32) DEFAULT NULL,
  `email_confirm_token` varchar(255) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `password_reset_token` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx-user-username` (`username`),
  KEY `idx-user-email` (`email`),
  KEY `idx-user-status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_user`
--

INSERT INTO `s_user` (`id`, `created_at`, `updated_at`, `username`, `auth_key`, `email_confirm_token`, `password_hash`, `password_reset_token`, `email`, `status`) VALUES
(1, 123213, 2341344, 'demo', NULL, NULL, '$2a$10$JTJf6/XqC94rrOtzuF397OHa4mbmZrVTBOQCmYD9U.obZRUut4BoC', NULL, 'admin@admin.ru', 1),
(9, 1461688629, 1461688629, 'admin', '', '', 'qawsedrf', '', 'admin@admin1.ru', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `s_users`
--

DROP TABLE IF EXISTS `s_users`;
CREATE TABLE IF NOT EXISTS `s_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `group_id` int(11) NOT NULL DEFAULT '0',
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `last_ip` varchar(15) DEFAULT NULL,
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `username` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `auth_key` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_users`
--

INSERT INTO `s_users` (`id`, `email`, `password`, `name`, `group_id`, `enabled`, `last_ip`, `created`, `username`, `status`, `auth_key`) VALUES
(9, 'admin@admin.ru', '$2a$10$JTJf6/XqC94rrOtzuF397OHa4mbmZrVTBOQCmYD9U.obZRUut4BoC', 'demo', 0, 0, NULL, '2016-06-01 15:40:53', 'demo', 1, NULL),
(7, 'admin@admin1.ru', '$2a$10$JTJf6/XqC94rrOtzuF397OHa4mbmZrVTBOQCmYD9U.obZRUut4BoC', 'admin', 0, 0, NULL, '2016-06-01 15:41:17', 'admin', 1, NULL),
(10, 'admin@admin.ru', '$2a$10$JTJf6/XqC94rrOtzuF397OHa4mbmZrVTBOQCmYD9U.obZRUut4BoC', 'demo1', 0, 0, '', '2016-06-01 15:40:53', 'demo1', 1, NULL),
(18, 'user', '$2y$13$kQS051I3/IDWv8YEXzhYQeCkIylx/ZlzUueC7kKN8vbEONub9d/9m', 'user', 0, 0, NULL, '2016-06-03 15:48:10', 'user', 1, 'cRUprVpn9dlUeYFkC75wezudnpxQmH72');

-- --------------------------------------------------------

--
-- Структура таблицы `s_variants`
--

DROP TABLE IF EXISTS `s_variants`;
CREATE TABLE IF NOT EXISTS `s_variants` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `sku` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` float(14,2) NOT NULL,
  `compare_price` float(14,2) DEFAULT NULL,
  `stock` mediumint(9) DEFAULT NULL,
  `position` int(11) NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `external_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `sku` (`sku`),
  KEY `price` (`price`),
  KEY `stock` (`stock`),
  KEY `position` (`position`),
  KEY `external_id` (`external_id`)
) ENGINE=MyISAM AUTO_INCREMENT=78 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `s_variants`
--

INSERT INTO `s_variants` (`id`, `product_id`, `sku`, `name`, `price`, `compare_price`, `stock`, `position`, `attachment`, `external_id`) VALUES
(1, 1, '', 'Белый', 44000.00, 0.00, NULL, 1, '', ''),
(2, 1, '', 'Черный', 42000.00, 0.00, NULL, 2, '', ''),
(3, 2, '', '', 19200.00, 0.00, NULL, 3, '', ''),
(4, 3, '', '', 16000.00, 0.00, NULL, 4, '', ''),
(5, 4, '', '', 20300.00, 0.00, NULL, 5, '', ''),
(6, 5, '', 'Белый', 6900.00, 0.00, NULL, 6, '', ''),
(7, 5, '', 'Черный', 7000.00, 0.00, NULL, 7, '', ''),
(8, 6, '', 'Фиолетовый', 12000.00, 0.00, NULL, 8, '', ''),
(9, 6, '', 'Бежевый', 11000.00, 0.00, NULL, 9, '', ''),
(10, 6, '', 'Черный', 10000.00, 0.00, NULL, 10, '', ''),
(11, 7, '', '', 20000.00, 0.00, NULL, 11, '', ''),
(12, 8, '', '', 7300.00, 0.00, NULL, 12, '', ''),
(13, 9, '', '', 10300.00, 0.00, NULL, 13, '', ''),
(14, 10, '', 'Малиновый', 5500.00, 0.00, NULL, 14, '', ''),
(15, 10, '', 'Голубой', 5600.00, 0.00, NULL, 15, '', ''),
(16, 10, '', 'Черный', 5700.00, 0.00, NULL, 16, '', ''),
(17, 10, '', 'Белый', 5200.00, 0.00, NULL, 17, '', ''),
(18, 10, '', 'Фиолетовый', 5300.00, 0.00, NULL, 18, '', ''),
(19, 11, '', '', 5000.00, 0.00, NULL, 19, '', ''),
(20, 12, '', '', 25000.00, 0.00, NULL, 20, '', ''),
(21, 13, '', '', 10000.00, 0.00, NULL, 21, '', ''),
(22, 14, '', '', 12000.00, 0.00, NULL, 22, '', ''),
(23, 15, '', '', 27000.00, 0.00, NULL, 23, '', ''),
(24, 16, '', '', 15700.00, 0.00, NULL, 24, '', ''),
(25, 17, '', '', 8500.00, 0.00, NULL, 25, '', ''),
(26, 18, '', '', 33000.00, 0.00, NULL, 26, '', ''),
(27, 19, '', '', 18000.00, 0.00, NULL, 27, '', ''),
(28, 20, '', '', 20000.00, 0.00, NULL, 28, '', ''),
(29, 21, '4300', '', 4000.00, 0.00, NULL, 29, '', ''),
(30, 22, '', '', 4500.00, 0.00, NULL, 30, '', ''),
(31, 23, '', '', 13000.00, 0.00, NULL, 31, '', ''),
(32, 24, '', '', 4500.00, 0.00, NULL, 32, '', ''),
(33, 25, '', '', 3000.00, 0.00, NULL, 33, '', ''),
(34, 26, '', '', 11000.00, 0.00, NULL, 34, '', ''),
(35, 27, '', '', 29000.00, 0.00, NULL, 35, '', ''),
(36, 28, '', '', 17000.00, 0.00, NULL, 36, '', ''),
(37, 29, '', '', 25000.00, 0.00, NULL, 37, '', ''),
(38, 30, '', '', 28000.00, 0.00, NULL, 38, '', ''),
(39, 31, '', '', 3500.00, 0.00, NULL, 39, '', ''),
(40, 32, '', '', 35000.00, 0.00, NULL, 40, '', ''),
(41, 33, '', '', 24000.00, 0.00, NULL, 41, '', ''),
(42, 34, '', '', 3700.00, 4000.00, NULL, 42, '', ''),
(43, 35, '', '', 3700.00, 4000.00, NULL, 43, '', ''),
(44, 36, '', '', 2900.00, 3500.00, NULL, 44, '', ''),
(45, 37, '', '', 9000.00, 0.00, NULL, 45, '', ''),
(46, 38, '', '', 3500.00, 0.00, NULL, 46, '', ''),
(47, 39, '', '', 11000.00, 0.00, NULL, 47, '', ''),
(48, 40, '', '', 3200.00, 0.00, NULL, 48, '', ''),
(49, 41, '', 'Оранжевый', 5500.00, 0.00, NULL, 49, '', ''),
(50, 41, '', 'Серебристый', 5500.00, 0.00, NULL, 50, '', ''),
(51, 41, '', 'Розовый', 5500.00, 0.00, NULL, 51, '', ''),
(52, 42, '', '', 15000.00, 0.00, NULL, 52, '', ''),
(53, 76, '32432', '314', 32434.00, 343.00, 1, 6, NULL, NULL),
(62, 75, 'dasf', 'asdf', 254.00, 25.00, 22, 3, NULL, NULL),
(63, 75, '54', '235', 435.00, 345.00, 254, 25, NULL, NULL),
(76, 94, '94', 'вариант 1', 1.00, NULL, NULL, 1, NULL, NULL),
(77, 95, '95', 'вариант 1', 1.00, NULL, NULL, 1, NULL, NULL);

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `s_auth_assignment`
--
ALTER TABLE `s_auth_assignment`
  ADD CONSTRAINT `s_auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `s_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `s_auth_item`
--
ALTER TABLE `s_auth_item`
  ADD CONSTRAINT `s_auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `s_auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `s_auth_item_child`
--
ALTER TABLE `s_auth_item_child`
  ADD CONSTRAINT `s_auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `s_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `s_auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `s_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
