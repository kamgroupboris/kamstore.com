-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Май 23 2016 г., 10:09
-- Версия сервера: 5.7.9
-- Версия PHP: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `kamstroy.com`
--

-- --------------------------------------------------------

--
-- Структура таблицы `auth_assignment`
--

DROP TABLE IF EXISTS `auth_assignment`;
CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) NOT NULL,
  `user_id` varchar(64) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `auth_item`
--

DROP TABLE IF EXISTS `auth_item`;
CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `rule_name` varchar(64) DEFAULT NULL,
  `data` text,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `auth_item_child`
--

DROP TABLE IF EXISTS `auth_item_child`;
CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `auth_rule`
--

DROP TABLE IF EXISTS `auth_rule`;
CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) NOT NULL,
  `data` text,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_articles`
--

DROP TABLE IF EXISTS `tbl_articles`;
CREATE TABLE IF NOT EXISTS `tbl_articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alias` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `meta_title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `img` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tags` text COLLATE utf8_unicode_ci,
  `status` int(11) NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `author_id` int(11) NOT NULL,
  `type_article` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'article',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `tbl_articles`
--

INSERT INTO `tbl_articles` (`id`, `alias`, `title`, `meta_title`, `description`, `content`, `img`, `tags`, `status`, `create_time`, `update_time`, `author_id`, `type_article`) VALUES
(4, 'arbitragh', 'Арбитраж', '', '', '<p>Арбитраж</p>\r\n', NULL, '', 2, 1460720801, 1460721100, 1, 'articles'),
(5, 'ispolnitelynoe-proizvodstvo', 'Исполнительное производство', '', '', '<p style="text-align:justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<h4 style="text-align:justify">Авада Кедавра!!!</h4>\r\n\r\n<p><span style="color:rgb(0, 0, 0); font-family:arial,helvetica,sans-serif; font-size:16px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span></p>\r\n', NULL, '', 2, 1460721257, 1461249623, 1, 'articles'),
(6, 'nalogovye-sbory', 'Налоговые сборы', '', '', '<p>Налоговые сборы</p>\r\n', NULL, '', 2, 1460726765, 1460726777, 1, 'articles'),
(11, 'novosty-1', 'Новость 1', '', '', '<p><span style="color:rgb(74, 74, 74); font-family:arial,helvetica,sans-serif; font-size:16px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span></p>\r\n', NULL, '', 1, 1460732012, 1461250356, 1, 'novosti'),
(12, 'novosty-dnya-2', 'Новость дня 2', '', '', '<p>Новость дня 2</p>\r\n', NULL, '', 1, 1460732135, 1460732135, 1, 'update'),
(15, 'kommentariy-2', 'Комментарий 2', '', '', '<p><span style="color:rgb(74, 74, 74); font-family:arial,helvetica,sans-serif; font-size:16px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span></p>\r\n', NULL, '', 2, 1460732762, 1461250500, 1, 'kommentarii'),
(16, 'kommentariy-3', 'Комментарий 3', '', '', '<p><span style="color:rgb(74, 74, 74); font-family:arial,helvetica,sans-serif; font-size:16px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span></p>\r\n', NULL, '', 2, 1460732772, 1461250541, 1, 'kommentarii'),
(19, 'novosty-3', 'Новость 3', '', '', '<p><span style="color:rgb(74, 74, 74); font-family:arial,helvetica,sans-serif; font-size:16px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span></p>\r\n', NULL, '', 2, 1460734051, 1461250423, 1, 'novosti'),
(21, 'novosty-2', 'Новость 2', '', '', '<p><span style="color:rgb(74, 74, 74); font-family:arial,helvetica,sans-serif; font-size:16px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span></p>\r\n', NULL, '', 2, 1460734066, 1461250392, 1, 'novosti'),
(22, 'kommentariy-1', 'Комментарий 1', 'Коментарий к закону', 'Коментарий к закону', '<p><span style="color:rgb(74, 74, 74); font-family:arial,helvetica,sans-serif; font-size:16px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span></p>\r\n', NULL, '', 2, 1460737203, 1461250512, 1, 'kommentarii'),
(48, 'dfasdfas', 'dasfdasf', '', '', '<p>adsfdasfdas</p>\r\n', '/uploads/Безымянный.png', '', 1, 1461058292, 1461058292, 1, 'update'),
(55, 'uslugi', 'Услуги', '', '', '<p><span style="background-color:rgb(238, 238, 238); font-family:helvetica neue,helvetica,arial,sans-serif; font-size:14px">Услуги</span></p>\r\n', NULL, '', 2, 1461060909, 1461237877, 1, 'articles'),
(56, 'regiony', 'Регионы', '', '', '<p><span style="background-color:rgb(238, 238, 238); font-family:helvetica neue,helvetica,arial,sans-serif; font-size:14px">Регионы</span></p>\r\n', NULL, '', 2, 1461061177, 1461237997, 1, 'articles'),
(67, 'praktika', 'Практика', '', '', '<p><span style="background-color:rgb(238, 238, 238); font-family:helvetica neue,helvetica,arial,sans-serif; font-size:14px">Практика</span></p>\r\n', NULL, '', 2, 1461238045, 1461238045, 1, 'articles'),
(68, 'stoimosty', 'Стоимость', '', '', '<p><span style="color:rgb(0, 0, 0); font-family:sans-serif; font-size:13.12px">Стоимость</span></p>\r\n', NULL, '', 2, 1461238094, 1461238094, 1, 'articles'),
(70, 'o-kompanii', 'О компании', '', '', '<p><span style="color:rgb(0, 0, 0); font-family:sans-serif; font-size:13.12px">О компании</span></p>\r\n', NULL, '', 2, 1461238183, 1461238183, 1, 'articles'),
(71, 'Online-zayavka', 'Online заявка', '', '', '<p><span style="color:rgb(0, 0, 0); font-family:sans-serif; font-size:13.12px">Online заявка</span></p>\r\n', NULL, '', 2, 1461238217, 1461238217, 1, 'update'),
(72, 'Online-zayavka', 'Online заявка', '', '', '<p><span style="color:rgb(0, 0, 0); font-family:sans-serif; font-size:13.12px">Online заявка</span></p>\r\n', NULL, '', 2, 1461238245, 1461238245, 1, 'articles'),
(73, 'bankrotstvo', 'Банкротство', '', '', '<p>Банкротство</p>\r\n', NULL, '', 2, 1461249080, 1461249080, 1, 'articles'),
(74, 'podgotovka-dokumentov', 'Подготовка документов', '', '', '<p>Подготовка документов</p>\r\n', NULL, '', 1, 1461249228, 1461249228, 1, 'articles'),
(75, 'delo-1', 'Дело №__1', '', '', '<p><span style="background-color:rgb(246, 249, 251); color:rgb(0, 0, 0); font-family:times new roman; font-size:medium">Предмет иска: Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,</span></p>\r\n', NULL, '', 2, 1461249726, 1461250077, 1, 'process'),
(76, 'delo-2', 'Дело №__2', '', '', '<p><span style="background-color:rgb(246, 249, 251); color:rgb(0, 0, 0); font-family:times new roman; font-size:medium">Предмет иска: Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,</span></p>\r\n', NULL, '', 1, 1461250139, 1461250139, 1, 'process'),
(77, 'delo-3', 'Дело №__3', '', '', '<p><span style="background-color:rgb(246, 249, 251); color:rgb(0, 0, 0); font-family:times new roman; font-size:medium">Предмет иска: Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,</span></p>\r\n', NULL, '', 1, 1461250160, 1461250160, 1, 'process'),
(78, 'delo-fiz-1', 'Дело Физ. №__1', '', '', '<p><span style="background-color:rgb(246, 249, 251); color:rgb(0, 0, 0); font-family:times new roman; font-size:medium">Предмет иска: Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,</span></p>\r\n', NULL, '', 1, 1461250248, 1461250248, 1, 'process'),
(79, 'delo-fiz-2', 'Дело Физ. №__2', '', '', '<p><span style="background-color:rgb(246, 249, 251); color:rgb(0, 0, 0); font-family:times new roman; font-size:medium">Предмет иска: Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,</span></p>\r\n', NULL, '', 1, 1461250275, 1461250275, 1, 'process'),
(80, 'delo-fiz-3', 'Дело Физ. №__3', '', '', '<p><span style="background-color:rgb(246, 249, 251); color:rgb(0, 0, 0); font-family:times new roman; font-size:medium">Предмет иска: Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,</span></p>\r\n', NULL, '', 1, 1461250302, 1461250302, 1, 'process');

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_comment`
--

DROP TABLE IF EXISTS `tbl_comment`;
CREATE TABLE IF NOT EXISTS `tbl_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `author` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `post_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_comment_post` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `tbl_comment`
--

INSERT INTO `tbl_comment` (`id`, `content`, `status`, `create_time`, `author`, `email`, `url`, `post_id`) VALUES
(1, 'Тестовый коментарий.', 2, 1230952187, 'Гога', 'tester@example.com', '', 2),
(2, 'вфыавфыавфыа', 2, 1460129830, 'фвыа', 'fdjkasldfjas@kdasf.fd', '', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_lookup`
--

DROP TABLE IF EXISTS `tbl_lookup`;
CREATE TABLE IF NOT EXISTS `tbl_lookup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `code` int(11) NOT NULL,
  `type` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `tbl_lookup`
--

INSERT INTO `tbl_lookup` (`id`, `name`, `code`, `type`, `position`) VALUES
(1, 'Проект', 1, 'PostStatus', 1),
(2, 'Опубликовано', 2, 'PostStatus', 2),
(3, 'Архив', 3, 'PostStatus', 3),
(4, 'На модерации', 1, 'CommentStatus', 1),
(5, 'Утвержденный', 2, 'CommentStatus', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_menu`
--

DROP TABLE IF EXISTS `tbl_menu`;
CREATE TABLE IF NOT EXISTS `tbl_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(156) NOT NULL,
  `url` varchar(156) NOT NULL,
  `type_menu` varchar(25) NOT NULL,
  `active` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `tbl_menu`
--

INSERT INTO `tbl_menu` (`id`, `label`, `url`, `type_menu`, `active`) VALUES
(1, 'Услуги', 'uslugi', 'top', 0),
(2, 'Регионы', 'regiony', 'top', 0),
(5, '	 Практика', 'praktika', 'top', 0),
(6, 'Стоимость', 'stoimosty', 'top', 0),
(8, 'О компании', 'o-kompanii', 'top', 0),
(10, 'Арбитраж', 'arbitragh', 'midle', 0),
(11, 'Исполнительное производство', 'ispolnitelynoe-proizvodstvo', 'midle', 0),
(12, 'Налоговые сборы', 'nalogovye-sbory', 'midle', 0),
(13, 'Банкротство', 'bankrotstvo', 'midle', 0),
(14, 'Подготовка документов', 'nalogovye-sbory', 'midle', 0),
(15, 'Контакты', 'contact', 'top', 0),
(16, 'Арбитраж 1', '', 'left', 0),
(17, 'Арбитраж 2', '', 'left', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_post`
--

DROP TABLE IF EXISTS `tbl_post`;
CREATE TABLE IF NOT EXISTS `tbl_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `tags` text COLLATE utf8_unicode_ci,
  `status` int(11) NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `author_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_post_author` (`author_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `tbl_post`
--

INSERT INTO `tbl_post` (`id`, `title`, `content`, `tags`, `status`, `create_time`, `update_time`, `author_id`) VALUES
(1, 'Welcome!', 'This blog system is developed using Yii. It is meant to demonstrate how to use Yii to build a complete real-world application. Complete source code may be found in the Yii releases.\r\n\r\nFeel free to try this system by writing new posts and postin9999999999999999999999999999999999999', 'yii, blog', 2, 1230952187, 1460114762, 1),
(2, 'A Test Post', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', 'test', 2, 1230952187, 1460456334, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_process`
--

DROP TABLE IF EXISTS `tbl_process`;
CREATE TABLE IF NOT EXISTS `tbl_process` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL,
  `status` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `tbl_process`
--

INSERT INTO `tbl_process` (`id`, `title`, `status`, `article_id`) VALUES
(1, 'Юрики', 2, 65),
(2, 'Юрики', 1, 66),
(3, 'Юрики', 1, 75),
(4, 'Юрики', 1, 76),
(5, 'Юрики', 1, 77),
(6, 'Юрики', 2, 78),
(7, 'Юрики', 2, 79),
(8, 'Юрики', 2, 80);

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_tag`
--

DROP TABLE IF EXISTS `tbl_tag`;
CREATE TABLE IF NOT EXISTS `tbl_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `frequency` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `tbl_tag`
--

INSERT INTO `tbl_tag` (`id`, `name`, `frequency`) VALUES
(1, 'yii', 1),
(2, 'blog', 1),
(3, 'test', 1),
(6, 'dasfdfas', 1),
(8, 'вторая третья', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `profile` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `username`, `password`, `email`, `profile`) VALUES
(1, 'demo', '$2a$10$JTJf6/XqC94rrOtzuF397OHa4mbmZrVTBOQCmYD9U.obZRUut4BoC', 'webmaster@example.com', NULL);

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `auth_item`
--
ALTER TABLE `auth_item`
  ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `tbl_comment`
--
ALTER TABLE `tbl_comment`
  ADD CONSTRAINT `FK_comment_post` FOREIGN KEY (`post_id`) REFERENCES `tbl_post` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD CONSTRAINT `FK_post_author` FOREIGN KEY (`author_id`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
